# snipetools – Einrichtung

## Was ist drin

```
snipetools/              ← dieser Ordner kommt auf den Server
├── index.html           Login + App (Home, Snipebot, Tracking, Inventar, Konto)
├── css/style.css        Design (iOS-Look, hell/dunkel automatisch)
├── js/app.js            Oberfläche, Tabs, Sheet, Tab-Sperre
├── js/auth.js           Login: accounts.txt lesen, Passwort-Hash prüfen, Sitzung
├── js/pbkdf2.js         Passwort-Hash in reinem JS – springt ein, wenn kein https (Testphase)
├── js/snipebot.js       Snipebot-Seite: Einstellungen, Filter, Lesezeichen, Steuerung des Vinted-Tabs
├── js/vinted-core.js    Vinted-Adressen, Filter, Auslesen der Angebote (auch im Lesezeichen enthalten)
├── inject/snipebot.min.js  der Snipebot fürs Lesezeichen (gebaut aus quellcode/)
├── js/dom.js, sheet.js  gemeinsame Helfer (DOM, Sheets von unten)
├── js/store.js          tracking: Buchungen lokal speichern, Beträge/Daten formatieren
├── accounts.txt         Deine Accounts (Benutzername | Hash | Subscription)
├── .htaccess            Apache: Security-Header, keine Verzeichnislisten (HTTPS-Zwang vorbereitet)
├── manifest.webmanifest Home-Bildschirm-App
└── icons/               App-Icons für den Home-Bildschirm

account-generator.html   ← bleibt bei dir, lokal öffnen (nicht hochladen)
quellcode/               ← Quellcode des Lesezeichens + Build-Skript, nicht hochladen
```

Es läuft kein Code auf dem Server – kein PHP, keine Datenbank. Der Server liefert nur
statische Dateien aus und stellt selbst keine Anfragen an andere Websites.

## 1. Hochladen

Den Ordner `snipetools/` komplett per SFTP/FTP auf den Webspace laden, **inklusive der
versteckten Datei `.htaccess`** (im FTP-Programm „versteckte Dateien anzeigen“ aktivieren).

Aufruf dann über `https://deine-domain.de/snipetools/` – oder den Inhalt direkt in den
Web-Root legen.

## Testphase: http reicht

Die App läuft aktuell auch über **http** (z. B. im eigenen Netz oder auf einem Testserver).
Der HTTPS-Zwang in `.htaccess` ist auskommentiert; ohne https übernimmt `js/pbkdf2.js` die
Passwortprüfung in reinem JavaScript (gleiches Ergebnis, nur 1–3 Sekunden statt Bruchteilen).

Vor dem Livegang: in `.htaccess` beim Block „HTTPS-Zwang“ die `#` am Zeilenanfang der fünf
Zeilen entfernen – mehr ist nicht nötig, der Login nutzt über https automatisch WebCrypto.

## 2. Accounts anlegen

1. `account-generator.html` auf deinem Rechner oder Handy im Browser öffnen (Doppelklick genügt).
2. Benutzername, Passwort und Subscription eintragen → **Zeile erzeugen** → **Zeile kopieren**.
3. Zeile unten in `snipetools/accounts.txt` einfügen (eine Zeile pro Account) und die Datei hochladen.

Format einer Zeile:

```
benutzername | pbkdf2$600000$<salt>$<hash> | subscription
```

- `subscription` ist derzeit nur `free`; fehlt das Feld, gilt `free`.
- Änderungen gelten sofort. Account löschen oder Passwort ändern → der Nutzer fliegt beim
  nächsten Aufruf raus.
- Der Demo-Zugang in der Datei (`demo` / `snipetools`) ist nur zum Testen – bitte löschen.

## 3. Auf dem iPhone

Seite in Safari öffnen → Teilen → **Zum Home-Bildschirm**. Die App läuft dann im Vollbild
mit eigenem Icon.

## Wo liegen die Daten?

- Alles im Browser des Nutzers (`localStorage`), nichts auf dem Server.
- Sitzung: `snipetools.session` – bleibt bestehen, bis sich der Nutzer ausloggt.
- Buchungen aus „Tracking“: `snipetools.tracking.<benutzername>` – pro Account getrennt.
- Snipebot-Einstellungen und Filter: `snipetools.snipebot.<benutzername>`. Angebote selbst: nie.
- Im Vinted-Tab: nur die Bot-Konfiguration im Sitzungsspeicher des Tabs (`snipetools.bot.config`).
  Browserdaten löschen = Buchungen weg; ein Export/Backup kann später ergänzt werden.

## Snipebot

Browser verbieten Webseiten, fremde Seiten auszulesen. Der Snipebot läuft deshalb **in einem
Vinted-Tab** und wird dort mit einem Lesezeichen gestartet. Alle Anfragen gehen von diesem Tab
aus – dein Browser, deine Vinted-Sitzung, kein Server, keine Erweiterung. Funktioniert in Safari
auf dem iPhone genauso wie am PC.

### Einmalig: Lesezeichen anlegen

In snipetools unter Snipebot → **Lesezeichen** steht die Anleitung für iPhone und PC:

- **iPhone/iPad:** „Code kopieren“ → irgendeine Seite als Lesezeichen sichern, Name „snipetools“ →
  Lesezeichen bearbeiten, Adresse löschen, Code einfügen.
- **PC:** den blauen Knopf „snipetools“ in die Lesezeichenleiste ziehen.

### Benutzen

1. In snipetools Filter und Einstellungen wählen, dann **Starten** tippen. Vinted öffnet sich in
   einem neuen Tab, direkt mit deiner Suche.
2. Im Vinted-Tab das Lesezeichen „snipetools“ antippen. Der Bot startet sofort.
3. **Am PC** meldet sich der Vinted-Tab bei snipetools: Die Angebote erscheinen als Kacheln in
   snipetools, der Vinted-Tab zeigt nur noch eine kleine Leiste. Start/Stopp, Filter und
   Intervall steuerst du weiter aus snipetools.
   **Auf dem iPhone** ruht der snipetools-Tab im Hintergrund – die Kacheln erscheinen deshalb
   direkt im Vinted-Tab als Overlay, im selben Design. Mit dem Pfeil minimieren, mit × beenden.

Der Bot geht auch ohne snipetools: Lesezeichen auf einer beliebigen Vinted-Suche antippen – er
übernimmt die Filter aus der Vinted-Adresse („Aktuelle Vinted-Suche verwenden“).

### Gut zu wissen

- Der Vinted-Tab muss offen bleiben. Lädt er neu oder wechselst du darin die Seite, einfach das
  Lesezeichen erneut antippen – Filter und Einstellungen merkt er sich für diesen Tab.
- Angebote öffnen sich immer in einem neuen Tab, damit der Bot weiterläuft.
- Am PC drosseln Browser Hintergrund-Tabs auf etwa eine Suche pro Minute. Für kürzere Intervalle
  den Vinted-Tab als eigenes Fenster sichtbar lassen. Auf dem iPhone sucht der Bot nur, solange
  Safari mit dem Vinted-Tab im Vordergrund ist.
- Angebote liegen nur im Speicher und verschwinden mit dem Tab. Gespeichert werden nur deine
  Filter und Einstellungen (in snipetools pro Account, im Vinted-Tab für die Sitzung des Tabs).
- **Filter-IDs:** Marken, Kategorien und Größen sind Zahlen aus der Vinted-Adresse:
  `brand_ids[]=53` (Nike), `catalog[]=1904`, `size_ids[]=207`. „Suche auf Vinted öffnen“ im
  Filter-Sheet zeigt dieselbe Suche bei Vinted – so lassen sich die IDs prüfen.
- **Updates:** Ändert sich der Bot, zeigt snipetools „Lesezeichen veraltet“ – dann den Code neu
  kopieren und im Lesezeichen ersetzen.
- **Technik:** Der Bot versucht nacheinander vier Wege und merkt sich den, der funktioniert:
  die Daten in der Katalogseite, die Angebotskarten im HTML, die Next.js-Daten direkt und – falls
  Vinted die Angebote erst im Browser nachlädt – die Seite unsichtbar im Tab laden und die fertigen
  Karten lesen. Klappt keiner, erscheint „Diagnose kopieren“ (im Vinted-Tab und in snipetools unter
  Einstellungen → Diagnose). Die Diagnose enthält nur Zählwerte und eine Strukturskizze der Seite,
  Texte und IDs sind ausgeblendet.
- **Vinted-Regeln:** Vinteds Nutzungsbedingungen untersagen automatisierte Zugriffe. Das Risiko
  liegt vor allem beim eigenen Vinted-Konto – Intervalle moderat halten.

### Lesezeichen neu bauen (nur bei Änderungen am Bot)

```
cd quellcode
npm install
node build.mjs        # schreibt snipetools/inject/snipebot.min.js
```

Bei Änderungen die Version in `snipetools/js/vinted-core.js` (`BOT_VERSION`) hochzählen, dann
erkennt snipetools alte Lesezeichen.

## Eine Sitzung pro Account

Die App läuft pro Account nur in einem Browser-Tab gleichzeitig: Wer sie in einem zweiten
Tab öffnet, übernimmt die Sitzung, der erste Tab wird gesperrt („Hier verwenden“ holt sie
zurück). Ein Logout gilt sofort für alle Tabs.

Geräteübergreifend (iPhone und PC gleichzeitig) lässt sich das ohne Serverlogik nicht
erzwingen – der Server speichert ja bewusst nichts.

## Sicherheit – was das Login kann und was nicht

- `accounts.txt` ist öffentlich abrufbar (der Browser muss sie lesen können). Deshalb stehen
  darin nur Passwort-Hashes (PBKDF2-SHA-256, 600 000 Runden), nie Klartext.
- Das Login regelt den Zugang zur Oberfläche, es ist kein Serverschutz: Wer die Dateien
  herunterlädt, kann den Code lesen. Für ein Tool, das ohnehin komplett lokal läuft, ist das
  normalerweise ausreichend.
- Wenn du zusätzlich einen harten Server-Login willst: In `.htaccess` ist ein auskommentierter
  Block für HTTP Basic Auth vorbereitet. Dann zeigt der Browser vor der App seinen eigenen
  (nicht gestaltbaren) Anmeldedialog.
- Die Content-Security-Policy in `.htaccess` erlaubt der App nur Verbindungen zum eigenen Server;
  Vinted-Fotos werden nur als Bilder eingebunden.
