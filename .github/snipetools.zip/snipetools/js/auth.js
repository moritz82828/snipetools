/* ==========================================================================
   snipetools – Auth
   accounts.txt enthält nur Passwort-Hashes (PBKDF2-HMAC-SHA-256).
   Die Sitzung liegt ausschließlich im Browser (localStorage).
   Über https rechnet WebCrypto, über http der JS-Fallback aus pbkdf2.js.
   ========================================================================== */

import { pbkdf2Sha256 } from './pbkdf2.js';

export const SESSION_KEY = 'snipetools.session';
const SESSION_VERSION = 2;
const ACCOUNTS_URL = 'accounts.txt';

/* ---------- accounts.txt ----------
   Format pro Zeile:   benutzername | passwort-hash | subscription
   Leere Zeilen und Zeilen, die mit # beginnen, werden ignoriert. */

export async function loadAccounts() {
  let response;
  try {
    response = await fetch(ACCOUNTS_URL, { cache: 'no-store', credentials: 'same-origin' });
  } catch (err) {
    throw new Error('accounts.txt konnte nicht geladen werden. Die App muss über einen Webserver (https) aufgerufen werden.');
  }
  if (!response.ok) {
    throw new Error(`accounts.txt konnte nicht geladen werden (HTTP ${response.status}).`);
  }
  return parseAccounts(await response.text());
}

export function parseAccounts(text) {
  const accounts = new Map();
  const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/);

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;

    const parts = line.split('|').map((p) => p.trim());
    if (parts.length < 2) continue;

    const [username, hash, subscription] = parts;
    if (!username || !hash) continue;

    accounts.set(username.toLowerCase(), {
      username,
      hash,
      subscription: subscription || 'free',
    });
  }
  return accounts;
}

/* ---------- Passwort-Prüfung ----------
   Hash-Format:  pbkdf2$<iterationen>$<salt-base64>$<hash-base64> */

const textEncoder = new TextEncoder();

function base64ToBytes(b64) {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function timingSafeEqual(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

export function hasWebCrypto() {
  return typeof crypto !== 'undefined' && !!crypto.subtle;
}

/* WebCrypto, wenn vorhanden (https); sonst reines JS (http, nur zum Testen). */
async function deriveBits(passwordBytes, salt, iterations, length) {
  if (hasWebCrypto()) {
    const key = await crypto.subtle.importKey('raw', passwordBytes, 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, length * 8);
    return new Uint8Array(bits);
  }
  return pbkdf2Sha256(passwordBytes, salt, iterations, length);
}

export async function verifyPassword(password, storedHash) {
  const parts = String(storedHash).split('$');
  if (parts.length !== 4 || parts[0] !== 'pbkdf2') return false;

  const iterations = parseInt(parts[1], 10);
  if (!Number.isFinite(iterations) || iterations < 1000) return false;

  let salt;
  let expected;
  try {
    salt = base64ToBytes(parts[2]);
    expected = base64ToBytes(parts[3]);
  } catch (err) {
    return false;
  }

  const derived = await deriveBits(textEncoder.encode(password.normalize('NFC')), salt, iterations, expected.length);
  return timingSafeEqual(derived, expected);
}

/* ---------- Sitzung ---------- */

export function readSession() {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const session = JSON.parse(raw);
    if (session && session.v === SESSION_VERSION && session.username) return session;
  } catch (err) {
    /* defekte Sitzung ignorieren */
  }
  return null;
}

export function writeSession(account) {
  const payload = JSON.stringify({
    v: SESSION_VERSION,
    username: account.username,
    subscription: account.subscription,
    hash: account.hash,
    since: Date.now(),
  });
  try {
    localStorage.setItem(SESSION_KEY, payload);
  } catch (err) {
    /* Speicher nicht verfügbar – Sitzung gilt dann nur bis zum Neuladen */
  }
}

export function clearSession() {
  try { localStorage.removeItem(SESSION_KEY); } catch (err) { /* ignorieren */ }
}
