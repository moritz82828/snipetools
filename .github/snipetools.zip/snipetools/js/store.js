/* ==========================================================================
   snipetools – Tracking-Speicher
   Alle Buchungen liegen im localStorage des Browsers, getrennt pro Account.
   Beträge werden als ganze Cent gespeichert (keine Rundungsfehler).
   ========================================================================== */

const STORE_VERSION = 1;

export class TrackingStore {
  constructor(username) {
    this.key = `snipetools.tracking.${String(username).toLowerCase()}`;
    this.entries = this.load();
  }

  load() {
    try {
      const raw = localStorage.getItem(this.key);
      if (!raw) return [];
      const data = JSON.parse(raw);
      if (data && data.v === STORE_VERSION && Array.isArray(data.entries)) return data.entries;
    } catch (err) {
      /* defekte Daten ignorieren */
    }
    return [];
  }

  save() {
    try {
      localStorage.setItem(this.key, JSON.stringify({ v: STORE_VERSION, entries: this.entries }));
    } catch (err) {
      /* Speicher voll oder gesperrt */
    }
  }

  /* type: 'in' | 'out', cents: ganze Zahl > 0, note: Text, date: 'YYYY-MM-DD' */
  add({ type, cents, note, date }) {
    const entry = {
      id: makeId(),
      type,
      cents,
      note: String(note || '').trim(),
      date,
      created: Date.now(),
    };
    this.entries.push(entry);
    this.save();
    return entry;
  }

  update(id, patch) {
    const entry = this.get(id);
    if (!entry) return null;
    Object.assign(entry, patch, { note: String(patch.note ?? entry.note).trim() });
    this.save();
    return entry;
  }

  remove(id) {
    const before = this.entries.length;
    this.entries = this.entries.filter((e) => e.id !== id);
    if (this.entries.length !== before) this.save();
  }

  get(id) {
    return this.entries.find((e) => e.id === id) || null;
  }

  /* Neueste zuerst: nach Datum, bei gleichem Datum nach Erfassungszeit */
  sorted() {
    return [...this.entries].sort((a, b) =>
      a.date === b.date ? b.created - a.created : (a.date < b.date ? 1 : -1)
    );
  }

  /* Summen für einen Monat ('YYYY-MM') */
  monthSummary(month) {
    let inCents = 0;
    let outCents = 0;
    let count = 0;
    for (const e of this.entries) {
      if (!e.date.startsWith(month)) continue;
      count++;
      if (e.type === 'in') inCents += e.cents;
      else outCents += e.cents;
    }
    return { inCents, outCents, count, saldoCents: inCents - outCents };
  }
}

function makeId() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
}

/* --------------------------------------------------------------------------
   Beträge
   -------------------------------------------------------------------------- */

const euro = new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' });

/* Cent → "12,50 €" – mit signed: "+12,50 €" / "−12,50 €" */
export function formatEuro(cents, { signed = false, type = null } = {}) {
  const abs = Math.abs(cents);
  const text = euro.format(abs / 100);
  if (!signed) return text;
  const negative = type ? type === 'out' : cents < 0;
  if (cents === 0 && !type) return text;
  return (negative ? '\u2212' : '+') + text;
}

/* Cent → Eingabewert "12,50" */
export function centsToInput(cents) {
  return (cents / 100).toFixed(2).replace('.', ',');
}

/* "12,50" / "12.50" / "1.234,56" / "12" → Cent, sonst null */
export function parseAmount(input) {
  let s = String(input || '').trim().replace(/[€\s]/g, '');
  if (!s) return null;

  if (s.includes(',') && s.includes('.')) {
    s = s.replace(/\./g, '').replace(',', '.');      // 1.234,56
  } else if (s.includes(',')) {
    s = s.replace(',', '.');                          // 12,50
  }
  if (!/^\d+(\.\d{0,2})?$/.test(s)) return null;

  const cents = Math.round(parseFloat(s) * 100);
  return cents > 0 ? cents : null;
}

/* --------------------------------------------------------------------------
   Datum (lokal, ohne Zeitzonen-Überraschungen)
   -------------------------------------------------------------------------- */

const pad = (n) => String(n).padStart(2, '0');

export function toISODate(date) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function todayISO() {
  return toISODate(new Date());
}

export function currentMonthKey() {
  return todayISO().slice(0, 7);
}

export function isValidISODate(iso) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return false;
  const [y, m, d] = iso.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  return date.getFullYear() === y && date.getMonth() === m - 1 && date.getDate() === d;
}

/* 'YYYY-MM-DD' → "Heute" / "Gestern" / "29.10.2026" */
export function formatDate(iso) {
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  if (iso === toISODate(today)) return 'Heute';
  if (iso === toISODate(yesterday)) return 'Gestern';
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

/* 'YYYY-MM' → "Oktober 2026" */
export function monthLabel(month) {
  const [y, m] = month.split('-').map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString('de-DE', { month: 'long', year: 'numeric' });
}
