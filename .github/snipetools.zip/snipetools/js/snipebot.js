/* ==========================================================================
   snipetools – Snipebot (Website-Seite)
   Die Suche selbst läuft im Vinted-Tab (Lesezeichen, siehe inject/). Diese
   Seite verwaltet Filter und Einstellungen, öffnet den Vinted-Tab, steuert
   ihn per Nachricht und zeigt die gemeldeten Angebote. Gespeichert werden
   nur Filter und Einstellungen (pro Account) – Angebote nie.
   ========================================================================== */

import { $, $$, el, icon, showError, clearError, segmented } from './dom.js';
import { openSheet, closeSheet } from './sheet.js';
import {
  BOT_VERSION, DOMAINS, DEFAULT_FILTERS, DEFAULT_BOT_SETTINGS, VINTED_ORIGIN_RE,
  parseIdList, buildCatalogUrl, describeFilters, encodeConfig,
} from './vinted-core.js';

const DEFAULT_SETTINGS = Object.freeze({
  ...DEFAULT_BOT_SETTINGS,
  domain: 'vinted.de',
  notify: false,
});

const STALE_MS = 3 * 60 * 1000;
const WINDOW_NAME = 'snipetools-vinted';

const bot = {
  username: null,
  settings: { ...DEFAULT_SETTINGS },
  filters: { ...DEFAULT_FILTERS },
  win: null,            // Vinted-Tab (von hier geöffnet oder per Nachricht bekannt)
  winOrigin: null,
  connected: false,
  waiting: false,       // Vinted-Tab geöffnet, Lesezeichen noch nicht angetippt
  version: null,
  lastSeen: 0,
  status: null,
  offers: [],           // nur im Speicher
  bookmarklet: null,
};

let ui = null;
let intervalCtl = null;
let perPageCtl = null;
let orderCtl = null;
let deviceCtl = null;
let watchTimer = null;

/* --------------------------------------------------------------------------
   Einstellungen & Filter (pro Account, localStorage)
   -------------------------------------------------------------------------- */

function storageKey() {
  return `snipetools.snipebot.${String(bot.username).toLowerCase()}`;
}

function loadPrefs() {
  bot.settings = { ...DEFAULT_SETTINGS };
  bot.filters = { ...DEFAULT_FILTERS };
  try {
    const raw = localStorage.getItem(storageKey());
    if (raw) {
      const data = JSON.parse(raw);
      if (data && data.v === 1) {
        const s = { ...data.settings };
        delete s.proxyUrl; // aus früherer Version
        bot.settings = { ...DEFAULT_SETTINGS, ...s };
        bot.filters = { ...DEFAULT_FILTERS, ...(data.filters || {}) };
      }
    }
  } catch (err) { /* defekte Daten ignorieren */ }
  if (!DOMAINS.includes(bot.settings.domain)) bot.settings.domain = 'vinted.de';
}

function savePrefs() {
  try {
    localStorage.setItem(storageKey(), JSON.stringify({ v: 1, settings: bot.settings, filters: bot.filters }));
  } catch (err) { /* Speicher nicht verfügbar */ }
}

function botSettings() {
  const { intervalSec, perPage, details, sound } = bot.settings;
  return { intervalSec, perPage, details, sound };
}

/* --------------------------------------------------------------------------
   Öffentliche Schnittstelle (von app.js)
   -------------------------------------------------------------------------- */

export function mountSnipebot(username) {
  if (!ui) bindUi();
  bot.username = username;
  loadPrefs();
  bot.offers = [];
  bot.status = null;
  renderAll();
  clearInterval(watchTimer);
  watchTimer = setInterval(watch, 3000);
}

export function unmountSnipebot() {
  clearInterval(watchTimer);
  if (bot.connected) send({ type: 'stop' });
  bot.offers = [];
  bot.status = null;
  bot.connected = false;
  bot.waiting = false;
  bot.username = null;
  if (ui) { ui.grid.replaceChildren(); ui.message.hidden = true; }
}

/* --------------------------------------------------------------------------
   Vinted-Tab öffnen und steuern
   -------------------------------------------------------------------------- */

function launch() {
  const config = { v: 1, origin: location.origin, filters: bot.filters, settings: botSettings(), autostart: true };
  const url = `${buildCatalogUrl(bot.settings.domain, bot.filters)}#snipetools=${encodeConfig(config)}`;
  const w = window.open(url, WINDOW_NAME);
  if (!w) {
    renderMessage('Der Browser hat das Öffnen des Vinted-Tabs blockiert. Bitte Pop-ups für diese Seite erlauben und erneut tippen.');
    return;
  }
  bot.win = w;
  bot.waiting = true;
  renderAll();
}

function send(msg) {
  if (!bot.win || !bot.winOrigin) return false;
  try {
    bot.win.postMessage({ source: 'snipetools-site', ...msg }, bot.winOrigin);
    return true;
  } catch (err) {
    return false;
  }
}

function sendConfig(autostart = false) {
  send({ type: 'config', config: { filters: bot.filters, settings: botSettings(), autostart } });
}

function toggleBot() {
  if (!bot.connected) { launch(); return; }
  const running = bot.status && bot.status.running;
  send({ type: running ? 'stop' : 'start' });
  if (bot.status) bot.status.running = !running;
  renderStatus();
}

window.addEventListener('message', (event) => {
  const msg = event.data;
  if (!msg || msg.source !== 'snipetools-bot') return;
  if (!VINTED_ORIGIN_RE.test(event.origin)) return;
  if (!bot.username) return;

  bot.win = event.source;
  bot.winOrigin = event.origin;
  bot.lastSeen = Date.now();
  bot.version = msg.version || null;

  if (msg.type === 'hello') {
    bot.connected = true;
    bot.waiting = false;
    sendConfig(true);
    renderAll();
    return;
  }
  if (msg.type === 'bye') {
    bot.connected = false;
    bot.status = null;
    renderAll();
    return;
  }
  if (msg.type === 'status') {
    bot.connected = true;
    bot.waiting = false;
    bot.status = msg.status || null;
    if (Array.isArray(msg.offers)) {
      const fresh = msg.offers.filter((o) => o && o.isNew).length;
      bot.offers = msg.offers.map(sanitizeOffer).filter(Boolean);
      renderGrid();
      if (fresh && bot.status && bot.status.lastNewCount) notifyNew(fresh);
    }
    renderStatus();
    renderMessage();
    renderSetupSummary();
  }
});

/* Nur erwartete Felder und nur Vinted-Adressen übernehmen */
function sanitizeOffer(o) {
  if (!o || typeof o !== 'object') return null;
  const str = (v) => (typeof v === 'string' ? v : null);
  const isVinted = (u) => typeof u === 'string' && /^https:\/\/([a-z0-9-]+\.)*vinted\.[a-z.]+\//i.test(u);
  const isImg = (u) => typeof u === 'string' && /^https:\/\//.test(u);
  const price = (p) => (p && typeof p.text === 'string' ? { text: p.text } : null);
  if (!isVinted(o.url)) return null;
  return {
    id: String(o.id),
    title: str(o.title) || '',
    url: o.url,
    price: price(o.price),
    total: price(o.total),
    photos: Array.isArray(o.photos) ? o.photos.filter(isImg).slice(0, 20) : [],
    brand: str(o.brand), size: str(o.size), condition: str(o.condition),
    category: str(o.category), description: str(o.description),
    isNew: !!o.isNew,
  };
}

function watch() {
  if (bot.win) {
    let closed = false;
    try { closed = bot.win.closed; } catch (err) { closed = false; }
    if (closed) {
      bot.win = null;
      bot.connected = false;
      bot.waiting = false;
      bot.status = null;
      renderAll();
      return;
    }
  }
  if (bot.connected && Date.now() - bot.lastSeen > STALE_MS) renderStatus();
}

function notifyNew(count) {
  if (!bot.settings.notify || !('Notification' in window) || Notification.permission !== 'granted') return;
  try {
    new Notification('snipetools', {
      body: count === 1 ? '1 neues Angebot' : `${count} neue Angebote`,
      icon: 'icons/icon-192.png',
      tag: 'snipetools-new',
    });
  } catch (err) { /* nicht verfügbar */ }
}

/* --------------------------------------------------------------------------
   Rendering
   -------------------------------------------------------------------------- */

function renderAll() {
  renderStatus();
  renderFilterSummary();
  renderSetupSummary();
  renderMessage();
  renderGrid();
}

function intervalLabel(sec) {
  return sec >= 60 ? `${Math.round(sec / 60)} min` : `${sec} s`;
}

function timeLabel(ts) {
  return new Date(ts).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function renderStatus() {
  if (!ui) return;
  const st = bot.status;
  const stale = bot.connected && Date.now() - bot.lastSeen > STALE_MS;

  if (!bot.connected) {
    ui.dot.className = 'bot-dot ' + (bot.waiting ? 'is-waiting' : 'is-off');
    ui.state.textContent = bot.waiting ? 'Warte auf Vinted-Tab' : 'Nicht verbunden';
    ui.detail.textContent = bot.waiting ? 'Dort das Lesezeichen „snipetools“ antippen' : 'Vinted-Tab mit dem Lesezeichen starten';
    ui.toggle.textContent = bot.waiting ? 'Erneut öffnen' : 'Starten';
    ui.toggle.className = 'btn-small btn-small-primary';
    return;
  }

  const running = st && st.running;
  ui.dot.className = 'bot-dot ' + (stale ? 'is-waiting' : running ? (st.error ? 'is-error' : 'is-running') : 'is-off');
  ui.state.textContent = stale ? 'Keine Rückmeldung' : running ? (st.busy ? 'Sucht …' : 'Läuft') : 'Gestoppt';

  const parts = [`Vinted-Tab · alle ${intervalLabel((st && st.intervalSec) || bot.settings.intervalSec)}`];
  if (st && st.lastRun) parts.push(`zuletzt ${timeLabel(st.lastRun)}`);
  if (running && st.lastNewCount) parts.push(`${st.lastNewCount} neu`);
  ui.detail.textContent = parts.join(' · ');

  ui.toggle.textContent = running ? 'Stopp' : 'Start';
  ui.toggle.className = 'btn-small ' + (running ? 'btn-small-danger' : 'btn-small-primary');
}

function renderFilterSummary() {
  if (ui) ui.filterSummary.textContent = describeFilters(bot.filters);
}

function renderSetupSummary() {
  if (!ui) return;
  if (bot.connected && bot.version && bot.version !== BOT_VERSION) {
    ui.setupSummary.textContent = `Veraltet (v${bot.version}) – bitte neu einrichten`;
    ui.setupSummary.classList.add('is-warn');
  } else if (bot.connected) {
    ui.setupSummary.textContent = `Verbunden · v${bot.version || BOT_VERSION}`;
    ui.setupSummary.classList.remove('is-warn');
  } else {
    ui.setupSummary.textContent = 'Einmalig einrichten · iPhone und PC';
    ui.setupSummary.classList.remove('is-warn');
  }
}

function renderMessage(override) {
  if (!ui) return;
  ui.message.replaceChildren();
  const st = bot.status;

  const show = (cls, ...nodes) => {
    ui.message.hidden = false;
    ui.message.className = 'card bot-message' + (cls ? ` ${cls}` : '');
    ui.message.append(...nodes.filter(Boolean));
  };

  if (override) {
    show('is-error', el('p', { text: override }));
    return;
  }
  if (bot.connected && st && st.error) {
    show('is-error',
      el('p', { class: 'bot-message-title', text: 'Suche fehlgeschlagen' }),
      el('p', { text: st.error }),
      st.lastStatus ? el('p', { class: 'bot-message-small', text: `HTTP ${st.lastStatus.status} · ${st.lastStatus.url}` }) : null,
      st.diag ? el('button', { type: 'button', class: 'btn-small btn-small-plain', 'data-action': 'copy-diag', text: 'Diagnose kopieren' }) : null);
    return;
  }
  if (bot.waiting) {
    show('',
      el('p', { class: 'bot-message-title', text: 'Vinted-Tab ist offen' }),
      el('p', { text: 'Wechsle in den Vinted-Tab und tippe auf das Lesezeichen „snipetools“. Am PC erscheinen die Angebote dann hier, auf dem iPhone direkt im Vinted-Tab.' }),
      el('button', { type: 'button', class: 'btn-small btn-small-plain', 'data-action': 'setup', text: 'Lesezeichen einrichten' }));
    return;
  }
  if (!bot.connected) {
    show('',
      el('p', { class: 'bot-message-title', text: 'So funktioniert der Snipebot' }),
      el('p', { text: 'Browser lassen Webseiten keine fremden Seiten auslesen. Der Snipebot läuft deshalb in einem Vinted-Tab: „Starten“ öffnet Vinted mit deinem Filter, dort tippst du auf das Lesezeichen „snipetools“. Gesucht wird dann direkt aus deinem Browser – ohne Server.' }),
      el('button', { type: 'button', class: 'btn-small btn-small-plain', 'data-action': 'setup', text: 'Lesezeichen einrichten' }));
    return;
  }
  if (!bot.offers.length && st && st.running && st.lastRun) {
    show('', el('p', { text: 'Keine Angebote zu diesem Filter gefunden.' }));
    return;
  }
  if (!bot.offers.length && st && !st.running) {
    show('', el('p', { text: 'Verbunden. Tippe auf Start, um die Suche zu beginnen.' }));
    return;
  }
  ui.message.hidden = true;
}

function offerCard(offer) {
  const meta = [offer.brand, offer.size, offer.condition].filter(Boolean).join(' · ');
  const photos = offer.photos.length ? offer.photos : [null];

  return el('a', { class: 'offer' + (offer.isNew ? ' is-new' : ''), href: offer.url, target: '_blank', rel: 'noopener noreferrer' },
    el('div', { class: 'offer-media' },
      el('div', { class: 'offer-photos' },
        ...photos.map((src, i) => (src
          ? el('img', { src, alt: i === 0 ? offer.title : '', loading: 'lazy', decoding: 'async', referrerpolicy: 'no-referrer' })
          : el('div', { class: 'offer-nophoto' }, icon(['M4 7h16v12H4z', 'M4 15l4-4 4 4 3-3 5 5'], 28))))),
      offer.isNew ? el('span', { class: 'offer-badge', text: 'Neu' }) : null,
      photos.length > 1 ? el('span', { class: 'offer-count', text: String(photos.length) }) : null,
    ),
    el('div', { class: 'offer-body' },
      el('div', { class: 'offer-price-row' },
        el('span', { class: 'offer-price', text: offer.price ? offer.price.text : '–' }),
        offer.total && offer.price && offer.total.text !== offer.price.text
          ? el('span', { class: 'offer-total', text: `inkl. ${offer.total.text}` }) : null,
      ),
      el('div', { class: 'offer-title', text: offer.title || 'Ohne Titel' }),
      meta ? el('div', { class: 'offer-meta', text: meta }) : null,
      offer.category ? el('div', { class: 'offer-cat', text: offer.category }) : null,
      offer.description ? el('p', { class: 'offer-desc', text: offer.description }) : null,
    ),
  );
}

function renderGrid() {
  if (!ui) return;
  ui.grid.replaceChildren(...bot.offers.map(offerCard));
  ui.footnote.hidden = !bot.offers.length;
}

/* --------------------------------------------------------------------------
   Einstellungen-Sheet
   -------------------------------------------------------------------------- */

function openSettings() {
  const s = bot.settings;
  intervalCtl.set(s.intervalSec);
  perPageCtl.set(s.perPage);
  ui.domain.value = s.domain;
  ui.details.checked = !!s.details;
  ui.notify.checked = !!s.notify;
  ui.sound.checked = !!s.sound;
  clearError(ui.settingsError);

  ui.connInfo.textContent = bot.connected
    ? `verbunden · Lesezeichen v${bot.version || '?'}`
    : bot.waiting ? 'geöffnet, Lesezeichen fehlt noch' : 'nicht verbunden';
  ui.connInfo.className = 'value' + (bot.connected ? '' : ' value-warn');
  const st = bot.status;
  const WAYS = { data: 'Seitendaten', cards: 'Angebotskarten', flight: 'Next-Daten direkt', frame: 'Laden im Hintergrund' };
  ui.diag.textContent = st && st.lastStatus
    ? `Letzte Anfrage: HTTP ${st.lastStatus.status}${st.lastRun ? ` um ${timeLabel(st.lastRun)}` : ''}`
      + `${st.strategy ? `\nAusgelesen über: ${WAYS[st.strategy] || st.strategy}` : ''}`
      + `\n${st.lastStatus.url}${st.error ? `\n${st.error}` : ''}`
    : 'Noch keine Rückmeldung vom Vinted-Tab.';
  ui.diagCopy.hidden = !(st && st.diag);
  ui.diagCopy.textContent = 'Diagnose kopieren';

  openSheet(ui.settingsSheet);
}

async function saveSettings(event) {
  event.preventDefault();
  clearError(ui.settingsError);

  const next = {
    ...bot.settings,
    intervalSec: Number(intervalCtl.get()) || 30,
    perPage: Number(perPageCtl.get()) || 40,
    domain: DOMAINS.includes(ui.domain.value) ? ui.domain.value : 'vinted.de',
    details: ui.details.checked,
    notify: ui.notify.checked,
    sound: ui.sound.checked,
  };
  if (next.notify && 'Notification' in window && Notification.permission !== 'granted') {
    try {
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') next.notify = false;
    } catch (err) { next.notify = false; }
  }
  bot.settings = next;
  savePrefs();
  closeSheet();
  renderAll();
  if (bot.connected) sendConfig(false);
}

/* --------------------------------------------------------------------------
   Filter-Sheet
   -------------------------------------------------------------------------- */

function openFilters() {
  const f = bot.filters;
  ui.fSearch.value = f.search || '';
  ui.fBrands.value = f.brandIds.join(', ');
  ui.fCatalogs.value = f.catalogIds.join(', ');
  ui.fSizes.value = f.sizeIds.join(', ');
  ui.fPriceFrom.value = f.priceFrom != null ? f.priceFrom : '';
  ui.fPriceTo.value = f.priceTo != null ? f.priceTo : '';
  for (const chip of ui.conditionChips) {
    const on = f.statusIds.includes(Number(chip.dataset.value));
    chip.classList.toggle('is-active', on);
    chip.setAttribute('aria-pressed', String(on));
  }
  orderCtl.set(f.order || 'newest_first');
  clearError(ui.filterError);
  openSheet(ui.filterSheet);
}

function readFilters() {
  const price = (v) => {
    const s = String(v).trim().replace(',', '.');
    if (!s) return null;
    const n = Number(s);
    return Number.isFinite(n) && n >= 0 ? Math.round(n * 100) / 100 : NaN;
  };
  const priceFrom = price(ui.fPriceFrom.value);
  const priceTo = price(ui.fPriceTo.value);
  if (Number.isNaN(priceFrom) || Number.isNaN(priceTo)) return { error: 'Bitte gültige Preise eingeben (z. B. 60 oder 59,99).' };
  if (priceFrom != null && priceTo != null && priceFrom > priceTo) return { error: '„Preis ab“ darf nicht über „Preis bis“ liegen.' };

  return {
    filters: {
      search: ui.fSearch.value.trim(),
      brandIds: parseIdList(ui.fBrands.value),
      catalogIds: parseIdList(ui.fCatalogs.value),
      sizeIds: parseIdList(ui.fSizes.value),
      priceFrom,
      priceTo,
      statusIds: ui.conditionChips.filter((c) => c.classList.contains('is-active')).map((c) => Number(c.dataset.value)),
      order: orderCtl.get() || 'newest_first',
    },
  };
}

function applyFilters(event) {
  event.preventDefault();
  clearError(ui.filterError);
  const read = readFilters();
  if (read.error) { showError(ui.filterError, read.error); return; }

  bot.filters = read.filters;
  savePrefs();
  closeSheet();
  bot.offers = [];
  renderAll();
  if (bot.connected) sendConfig(false);
}

function resetFilters() {
  bot.filters = { ...DEFAULT_FILTERS };
  savePrefs();
  openFilters();
  renderFilterSummary();
  if (bot.connected) sendConfig(false);
}

function openOnVinted() {
  const read = readFilters();
  window.open(buildCatalogUrl(bot.settings.domain, read.filters || bot.filters), '_blank', 'noopener');
}

/* --------------------------------------------------------------------------
   Lesezeichen einrichten
   -------------------------------------------------------------------------- */

/* gleiche Kodierung wie quellcode/build.mjs */
export function bookmarkletFrom(code) {
  return 'javascript:' + code.trim().replace(/[%#\s]|[^\x00-\x7f]/g, (c) => encodeURIComponent(c));
}

async function loadBookmarklet() {
  if (bot.bookmarklet) return bot.bookmarklet;
  const res = await fetch('inject/snipebot.min.js', { cache: 'no-cache' });
  if (!res.ok) throw new Error(`Lesezeichen-Code nicht gefunden (HTTP ${res.status}).`);
  bot.bookmarklet = bookmarkletFrom(await res.text());
  return bot.bookmarklet;
}

async function openSetup() {
  const isApple = /iPhone|iPad|iPod/.test(navigator.userAgent)
    || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  deviceCtl.set(isApple || matchMedia('(pointer: coarse)').matches ? 'ios' : 'pc');
  showSteps(deviceCtl.get());
  ui.bmCopy.textContent = 'Code kopieren';
  ui.bmInfo.textContent = 'Lade …';
  openSheet(ui.setupSheet);

  try {
    const code = await loadBookmarklet();
    ui.bmCode.value = code;
    ui.bmLink.setAttribute('href', code);
    ui.bmInfo.textContent = `Lesezeichen v${BOT_VERSION} · ${Math.round(code.length / 1000)} KB`;
  } catch (err) {
    ui.bmInfo.textContent = err.message;
  }
}

function showSteps(device) {
  for (const list of ui.steps) list.hidden = list.dataset.device !== device;
  ui.bmLink.hidden = device !== 'pc';
}

async function copyBookmarklet() {
  const text = ui.bmCode.value;
  if (!text) return;
  let ok = false;
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      ok = true;
    }
  } catch (err) { ok = false; }
  if (!ok) {
    ui.bmCode.focus();
    ui.bmCode.select();
    ui.bmCode.setSelectionRange(0, text.length);
    try { ok = document.execCommand('copy'); } catch (err) { ok = false; }
  }
  ui.bmCopy.textContent = ok ? 'Kopiert' : 'Code markiert – jetzt kopieren';
}

async function copyText(text) {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (err) { /* Ersatzweg unten */ }
  const ta = el('textarea', { readonly: true, class: 'sr-only' });
  ta.value = text;
  document.body.append(ta);
  ta.select();
  let ok = false;
  try { ok = document.execCommand('copy'); } catch (err) { ok = false; }
  ta.remove();
  return ok;
}

async function copyDiag(button) {
  const diag = bot.status && bot.status.diag;
  if (!diag) return;
  const ok = await copyText(JSON.stringify(diag, null, 2));
  button.textContent = ok ? 'Kopiert' : 'Kopieren nicht möglich';
}

/* --------------------------------------------------------------------------
   Verdrahtung
   -------------------------------------------------------------------------- */

function bindUi() {
  ui = {
    dot: $('#bot-dot'),
    state: $('#bot-state'),
    detail: $('#bot-detail'),
    toggle: $('#bot-toggle'),
    filterBtn: $('#snipebot-filter'),
    filterSummary: $('#filter-summary'),
    setupBtn: $('#snipebot-setup'),
    setupSummary: $('#setup-summary'),
    settingsBtn: $('#snipebot-settings'),
    message: $('#bot-message'),
    grid: $('#bot-grid'),
    footnote: $('#bot-footnote'),

    settingsSheet: $('#settings-sheet'),
    settingsError: $('#settings-error'),
    domain: $('#set-domain'),
    details: $('#set-details'),
    notify: $('#set-notify'),
    sound: $('#set-sound'),
    connInfo: $('#set-connection'),
    diag: $('#set-diag'),
    diagCopy: $('#set-diag-copy'),

    filterSheet: $('#filter-sheet'),
    filterError: $('#filter-error'),
    fSearch: $('#f-search'),
    fBrands: $('#f-brands'),
    fCatalogs: $('#f-catalogs'),
    fSizes: $('#f-sizes'),
    fPriceFrom: $('#f-price-from'),
    fPriceTo: $('#f-price-to'),
    conditionChips: $$('#f-conditions .chip'),

    setupSheet: $('#setup-sheet'),
    steps: $$('#setup-sheet .steps'),
    bmLink: $('#bm-link'),
    bmCode: $('#bm-code'),
    bmCopy: $('#bm-copy'),
    bmInfo: $('#bm-info'),
  };

  intervalCtl = segmented($('#set-interval'));
  perPageCtl = segmented($('#set-perpage'));
  orderCtl = segmented($('#f-order'));
  deviceCtl = segmented($('#setup-device'), showSteps);

  ui.domain.replaceChildren(...DOMAINS.map((d) => el('option', { value: d, text: d })));

  ui.toggle.addEventListener('click', toggleBot);
  ui.settingsBtn.addEventListener('click', openSettings);
  ui.filterBtn.addEventListener('click', openFilters);
  ui.setupBtn.addEventListener('click', openSetup);
  ui.message.addEventListener('click', (event) => {
    if (event.target.closest('[data-action="setup"]')) openSetup();
    const copy = event.target.closest('[data-action="copy-diag"]');
    if (copy) copyDiag(copy);
  });
  ui.diagCopy.addEventListener('click', () => copyDiag(ui.diagCopy));

  ui.settingsSheet.addEventListener('submit', saveSettings);
  $('#settings-cancel').addEventListener('click', () => closeSheet());

  ui.filterSheet.addEventListener('submit', applyFilters);
  $('#filter-cancel').addEventListener('click', () => closeSheet());
  $('#f-reset').addEventListener('click', resetFilters);
  $('#f-open').addEventListener('click', openOnVinted);
  for (const chip of ui.conditionChips) {
    chip.addEventListener('click', () => {
      const on = !chip.classList.contains('is-active');
      chip.classList.toggle('is-active', on);
      chip.setAttribute('aria-pressed', String(on));
    });
  }

  $('#setup-done').addEventListener('click', () => closeSheet());
  ui.bmCopy.addEventListener('click', copyBookmarklet);
  // Der Knopf ist zum Ziehen gedacht – hier angeklickt würde er nichts tun
  ui.bmLink.addEventListener('click', (event) => {
    event.preventDefault();
    ui.bmInfo.textContent = 'Den Knopf mit der Maus in die Lesezeichenleiste ziehen – klicken startet ihn nur auf Vinted.';
  });
}
