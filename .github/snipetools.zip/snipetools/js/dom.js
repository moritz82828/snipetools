/* ==========================================================================
   snipetools – DOM-Helfer (Inhalte immer als Text, nie als HTML)
   ========================================================================== */

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

export function el(tag, props = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (value == null || value === false) continue;
    if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key.startsWith('data-')) node.dataset[key.slice(5)] = value;
    else node.setAttribute(key, value === true ? '' : value);
  }
  for (const child of children) {
    if (child == null || child === false) continue;
    node.append(typeof child === 'string' ? document.createTextNode(child) : child);
  }
  return node;
}

/* SVG-Symbol aus Pfad-Daten (24×24, Linienstil wie in der Tab-Leiste) */
export function icon(paths, size = 22) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('width', size);
  svg.setAttribute('height', size);
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '1.9');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.setAttribute('aria-hidden', 'true');
  for (const d of [].concat(paths)) {
    const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    p.setAttribute('d', d);
    svg.append(p);
  }
  return svg;
}

export function showError(target, message) {
  target.textContent = message;
  target.hidden = false;
  target.classList.remove('shake');
  void target.offsetWidth; // Animation neu starten
  target.classList.add('shake');
}

export function clearError(target) {
  target.hidden = true;
  target.textContent = '';
}

/* Segment-Schalter: Buttons mit data-value in einem Container, ein aktiver Wert */
export function segmented(container, onChange) {
  const buttons = $$('button[data-value]', container);
  const set = (value) => {
    for (const b of buttons) {
      const active = b.dataset.value === String(value);
      b.classList.toggle('is-active', active);
      b.setAttribute('aria-pressed', String(active));
    }
    container.dataset.value = String(value);
  };
  for (const b of buttons) {
    b.addEventListener('click', () => { set(b.dataset.value); if (onChange) onChange(b.dataset.value); });
  }
  return { set, get: () => container.dataset.value };
}
