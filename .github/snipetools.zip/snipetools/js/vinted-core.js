/* ==========================================================================
   snipetools – Vinted-Kern
   Reine Funktionen ohne Netzwerkzugriff. Wird von der Website (Filter,
   Links) und vom Snipebot-Lesezeichen (Auslesen der Angebote) benutzt.
   ========================================================================== */

export const BOT_VERSION = '1.1.0';

export const DOMAINS = [
  'vinted.de', 'vinted.at', 'vinted.fr', 'vinted.nl', 'vinted.be', 'vinted.it',
  'vinted.es', 'vinted.pl', 'vinted.co.uk', 'vinted.com',
];

export const VINTED_ORIGIN_RE = /^https:\/\/(www\.)?vinted\.(de|at|fr|nl|be|it|es|pl|co\.uk|com)$/;

const CURRENCIES = { 'vinted.co.uk': 'GBP', 'vinted.pl': 'PLN', 'vinted.com': 'USD' };

export const CONDITIONS = [
  { id: 6, label: 'Neu mit Etikett' },
  { id: 1, label: 'Neu ohne Etikett' },
  { id: 2, label: 'Sehr gut' },
  { id: 3, label: 'Gut' },
  { id: 4, label: 'Zufriedenstellend' },
];

export const DEFAULT_FILTERS = Object.freeze({
  search: '',
  brandIds: [],
  catalogIds: [],
  sizeIds: [],
  priceFrom: null,
  priceTo: null,
  statusIds: [],
  order: 'newest_first',
});

export const DEFAULT_BOT_SETTINGS = Object.freeze({
  intervalSec: 30,
  perPage: 40,
  details: false,
  sound: false,
});

/* "53, 14 ; 1904" → [53, 14, 1904] */
export function parseIdList(text) {
  return String(text || '')
    .split(/[^\d]+/)
    .filter(Boolean)
    .map(Number)
    .filter((n) => Number.isInteger(n) && n > 0);
}

export function currencyFor(domain) {
  return CURRENCIES[domain] || 'EUR';
}

/* "www.vinted.de" → "vinted.de" */
export function domainFromHost(host) {
  return String(host || '').replace(/^www\./, '');
}

/* --------------------------------------------------------------------------
   Filter ⇄ Vinted-Adresse
   -------------------------------------------------------------------------- */

export function catalogQuery(domain, filters, page = 1) {
  const p = new URLSearchParams();
  if (filters.search) p.set('search_text', filters.search);
  (filters.brandIds || []).forEach((id) => p.append('brand_ids[]', id));
  (filters.catalogIds || []).forEach((id) => p.append('catalog[]', id));
  (filters.sizeIds || []).forEach((id) => p.append('size_ids[]', id));
  (filters.statusIds || []).forEach((id) => p.append('status_ids[]', id));
  if (filters.priceFrom != null) p.set('price_from', filters.priceFrom);
  if (filters.priceTo != null) p.set('price_to', filters.priceTo);
  p.set('currency', currencyFor(domain));
  p.set('order', filters.order || 'newest_first');
  if (page > 1) p.set('page', String(page));
  return p.toString();
}

export function buildCatalogUrl(domain, filters, page = 1) {
  return `https://www.${domain}/catalog?${catalogQuery(domain, filters, page)}`;
}

/* Filter aus einer Vinted-Katalogadresse lesen (für „aktuelle Suche verwenden“) */
export function filtersFromSearch(search) {
  const p = new URLSearchParams(search);
  const ids = (...keys) => keys.flatMap((k) => p.getAll(k)).flatMap((v) => parseIdList(v));
  const price = (k) => {
    const v = p.get(k);
    if (v == null || v === '') return null;
    const n = Number(String(v).replace(',', '.'));
    return Number.isFinite(n) && n >= 0 ? n : null;
  };
  const order = p.get('order');
  return {
    search: (p.get('search_text') || '').trim(),
    brandIds: ids('brand_ids[]', 'brand_ids', 'brand_id'),
    catalogIds: ids('catalog[]', 'catalog_ids[]', 'catalog_ids', 'catalog_id'),
    sizeIds: ids('size_ids[]', 'size_ids', 'size_id'),
    priceFrom: price('price_from'),
    priceTo: price('price_to'),
    statusIds: ids('status_ids[]', 'status_ids', 'status'),
    order: ['newest_first', 'price_low_to_high', 'price_high_to_low', 'relevance'].includes(order) ? order : 'newest_first',
  };
}

export function sameFilters(a, b) {
  const norm = (f) => JSON.stringify({ ...DEFAULT_FILTERS, ...f });
  return norm(a) === norm(b);
}

/* Kurzbeschreibung eines Filters, z. B. „nike dunk“ · Marke 53 · bis 60 € */
export function describeFilters(f) {
  const parts = [];
  if (f.search) parts.push(`„${f.search}“`);
  if (f.brandIds && f.brandIds.length) parts.push(`${f.brandIds.length === 1 ? 'Marke' : 'Marken'} ${f.brandIds.join(', ')}`);
  if (f.catalogIds && f.catalogIds.length) parts.push(`Kategorie ${f.catalogIds.join(', ')}`);
  if (f.sizeIds && f.sizeIds.length) parts.push(`Größe ${f.sizeIds.join(', ')}`);
  if (f.priceFrom != null || f.priceTo != null) {
    parts.push(f.priceFrom != null && f.priceTo != null ? `${f.priceFrom}–${f.priceTo} €`
      : f.priceTo != null ? `bis ${f.priceTo} €` : `ab ${f.priceFrom} €`);
  }
  if (f.statusIds && f.statusIds.length) {
    parts.push(f.statusIds.map((id) => (CONDITIONS.find((c) => c.id === id) || {}).label).filter(Boolean).join('/'));
  }
  parts.push(f.order === 'price_low_to_high' ? 'Günstigste zuerst'
    : f.order === 'price_high_to_low' ? 'Teuerste zuerst'
      : f.order === 'relevance' ? 'Relevanz' : 'Neueste zuerst');
  return parts.join(' · ');
}

/* --------------------------------------------------------------------------
   Konfiguration für das Lesezeichen (Base64url-JSON in der Adresse)
   -------------------------------------------------------------------------- */

export function encodeConfig(obj) {
  const bytes = new TextEncoder().encode(JSON.stringify(obj));
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function decodeConfig(str) {
  try {
    const b64 = String(str).replace(/-/g, '+').replace(/_/g, '/');
    const bin = atob(b64 + '==='.slice((b64.length + 3) % 4));
    const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
    return JSON.parse(new TextDecoder().decode(bytes));
  } catch (err) {
    return null;
  }
}

/* --------------------------------------------------------------------------
   Auslesen der Angebote aus der Katalogseite
   Mehrere unabhängige Wege, damit eine Änderung bei Vinted nicht gleich
   alles lahmlegt. Keine großen regulären Ausdrücke über die ganze Seite
   (Safari bricht bei sehr langen Treffern still ab).
   -------------------------------------------------------------------------- */

/* Inhalt aller self.__next_f.push([1,"…"])-Aufrufe (Next.js-„Flight“-Daten) */
export function flightFromHtml(html) {
  const out = [];
  const marker = '__next_f.push([1,';
  let i = 0;
  while ((i = html.indexOf(marker, i)) !== -1) {
    let j = i + marker.length;
    while (html[j] === ' ' || html[j] === '\n' || html[j] === '\t') j++;
    if (html[j] !== '"') { i = j; continue; }
    let k = j + 1;
    while (k < html.length) {
      const c = html.charCodeAt(k);
      if (c === 92) k += 2;            // Backslash: nächstes Zeichen überspringen
      else if (c === 34) break;        // schließendes "
      else k++;
    }
    try { out.push(JSON.parse(html.slice(j, k + 1))); } catch (err) { /* Chunk überspringen */ }
    i = k + 1;
  }
  return out.join('');
}

/* Flight-Zeilen „id:JSON“ einzeln parsen */
export function parseFlightRows(text) {
  const rows = [];
  if (!text) return rows;
  for (const line of text.split('\n')) {
    const colon = line.indexOf(':');
    if (colon < 1 || colon > 8) continue;
    const payload = line.slice(colon + 1);
    const first = payload[0];
    if (first !== '[' && first !== '{') continue;
    try { rows.push(JSON.parse(payload)); } catch (err) { /* keine JSON-Zeile */ }
  }
  return rows;
}

function isNumericId(id) {
  return (typeof id === 'number' && Number.isFinite(id) && id > 0)
    || (typeof id === 'string' && /^\d{4,}$/.test(id));
}

/* Sieht ein Objekt wie ein Angebot aus? (alte und neue Form) */
export function isOfferLike(o) {
  if (!o || typeof o !== 'object' || Array.isArray(o) || !isNumericId(o.id)) return false;
  if (o.productItem && typeof o.productItem === 'object') return true;
  const title = typeof o.title === 'string';
  const price = o.price != null || o.total_item_price != null || o.totalItemPrice != null;
  const media = o.photo != null || o.photos != null || o.thumbnail != null;
  const link = (typeof o.url === 'string' && /\/items\/\d+/.test(o.url)) || (typeof o.path === 'string' && /\/items\/\d+/.test(o.path));
  return title && price && (media || link);
}

/* Datenbaum nach Angeboten durchsuchen, egal unter welchem Schlüssel sie liegen */
export function collectOffers(node, found = new Map(), depth = 0) {
  if (!node || typeof node !== 'object' || depth > 80) return found;
  if (Array.isArray(node)) {
    for (const x of node) collectOffers(x, found, depth + 1);
    return found;
  }
  if (isOfferLike(node)) {
    const id = String(node.id);
    if (!found.has(id)) found.set(id, node);
    return found;
  }
  for (const key in node) collectOffers(node[key], found, depth + 1);
  return found;
}

/* Strategie 1: Next.js-Daten (Flight oder __NEXT_DATA__) */
export function offersFromData(html, origin) {
  const found = new Map();
  for (const row of parseFlightRows(flightFromHtml(html))) collectOffers(row, found);

  if (found.size === 0) {
    const start = html.indexOf('id="__NEXT_DATA__"');
    if (start !== -1) {
      const open = html.indexOf('>', start);
      const close = html.indexOf('</script>', open);
      if (open !== -1 && close !== -1) {
        try { collectOffers(JSON.parse(html.slice(open + 1, close)), found); } catch (err) { /* ignorieren */ }
      }
    }
  }
  return Array.from(found.values()).map((raw) => normalizeItem(raw, origin));
}

/* Strategie 2: Flight-Antwort direkt (Anfrage mit „RSC: 1“) */
export function offersFromFlight(text, origin) {
  const found = new Map();
  for (const row of parseFlightRows(text)) collectOffers(row, found);
  return Array.from(found.values()).map((raw) => normalizeItem(raw, origin));
}

/* Strategie 3: die sichtbaren Angebotskarten im HTML bzw. im gerenderten Dokument */
const NUM = '\\d{1,3}(?:[.\\u00a0\\u202f ]\\d{3})+(?:[.,]\\d{1,2})?|\\d+(?:[.,]\\d{1,2})?';
const PRICE_RE = new RegExp(`(?:[€£$]\\s?(?:${NUM})|(?:${NUM})\\s?(?:€|£|zł|\\$|Kč|Ft|lei))`, 'g');
const PRICE_TEST = /(?:[€£$]\s?\d|\d\s?(?:€|£|zł|\$|Kč|Ft|lei))/;
const LABEL_SPLIT = /,\s*(?:Marke|Brand|Marque|Merk|Marca|Zustand|Condition|État|Staat|Condizione|Estado|Größe|Size|Taille|Maat|Taglia|Talla)\s*:/i;

function bestImage(img) {
  if (!img) return null;
  const set = img.getAttribute('srcset') || img.getAttribute('data-srcset');
  if (set) {
    const best = set.split(',').map((part) => part.trim().split(/\s+/))
      .map(([url, w]) => ({ url, w: parseInt(w, 10) || 0 }))
      .sort((x, y) => y.w - x.w)[0];
    if (best && /^https?:\/\//.test(best.url)) return best.url;
  }
  const src = img.getAttribute('src') || img.getAttribute('data-src');
  return src && /^https?:\/\//.test(src) ? src : null;
}

function cardFor(anchor) {
  let el = anchor;
  for (let i = 0; i < 8 && el.parentElement; i++) {
    el = el.parentElement;
    const tid = el.getAttribute && el.getAttribute('data-testid');
    if (tid && (/^product-item-id-\d+$/.test(tid) || tid === 'grid-item')) return el;
    if (el.querySelector('img') && PRICE_TEST.test(el.textContent || '')) return el;
  }
  return anchor.parentElement || anchor;
}

export function offersFromDocument(doc, origin) {
  const found = new Map();
  for (const a of doc.querySelectorAll('a[href*="/items/"]')) {
    const m = /\/items\/(\d+)/.exec(a.getAttribute('href') || '');
    if (!m || found.has(m[1])) continue;
    const id = m[1];
    const card = cardFor(a);
    const img = card.querySelector('img');
    const label = a.getAttribute('title') || a.getAttribute('aria-label') || (img && img.getAttribute('alt')) || '';
    const text = (card.textContent || '').replace(/\s+/g, ' ');
    const prices = (label.match(PRICE_RE) || text.match(PRICE_RE) || []).map((p) => p.trim());
    const titleEl = card.querySelector('[data-testid$="--description-title"], [data-testid$="--title"]');
    const title = (label.split(LABEL_SPLIT)[0] || (titleEl && titleEl.textContent) || '').trim();
    const photo = bestImage(img);
    if (!prices.length && !photo) continue;

    const fromLabel = parseAccessibilityLabel(label);
    const subtitle = card.querySelector('[data-testid$="--description-subtitle"]');
    found.set(id, {
      id,
      title: title || 'Ohne Titel',
      url: absoluteUrl(a.getAttribute('href'), origin, id),
      price: prices[0] ? { text: prices[0], amount: null } : null,
      total: prices[1] ? { text: prices[1], amount: null } : null,
      photos: photo ? [photo] : [],
      brand: fromLabel.brand,
      size: fromLabel.size || (subtitle ? subtitle.textContent.trim() : null),
      condition: fromLabel.condition,
      category: null,
      description: null,
    });
  }
  return Array.from(found.values());
}

export function offersFromHtmlDom(html, origin) {
  if (typeof DOMParser === 'undefined') return [];
  const doc = new DOMParser().parseFromString(html, 'text/html');
  return offersFromDocument(doc, origin);
}

/* Kurzbefund der Seite für die Diagnose – Zählwerte und Strukturskizze, keine Inhalte */
function count(hay, needle) {
  let n = 0;
  let i = 0;
  while ((i = hay.indexOf(needle, i)) !== -1) { n++; i += needle.length; }
  return n;
}

export function describeHtml(html) {
  const flight = flightFromHtml(html);
  const rows = parseFlightRows(flight);
  const t = /<title[^>]*>([^<]{0,120})/i.exec(html);
  let sketch = null;
  const idx = flight.indexOf('productItem');
  const src = idx !== -1 ? flight : html;
  const at = idx !== -1 ? idx : html.indexOf('/items/');
  if (at !== -1) {
    sketch = src.slice(Math.max(0, at - 250), at + 650)
      .replace(/"((?:[^"\\]|\\.){10,})"/g, '"…"')   // längere Texte ausblenden
      .replace(/\d{6,}/g, '#');                     // IDs ausblenden
  }
  return {
    bytes: html.length,
    title: t ? t[1].trim() : null,
    nextF: count(html, '__next_f.push'),
    flightChars: flight.length,
    flightJsonRows: rows.length,
    productItem: count(html, 'productItem'),
    itemLinks: count(html, '/items/'),
    testIds: count(html, 'product-item-id-'),
    nextData: html.includes('__NEXT_DATA__'),
    sketch,
  };
}

/* Alter Name, falls noch irgendwo benutzt */
export function extractItemsFromHtml(html) {
  const found = new Map();
  for (const row of parseFlightRows(flightFromHtml(html))) collectOffers(row, found);
  return found.size ? Array.from(found.values()) : null;
}

/* --------------------------------------------------------------------------
   Vereinheitlichen – nur die Felder, die angezeigt werden
   -------------------------------------------------------------------------- */

function money(amount, currency) {
  const n = Number(amount);
  if (!Number.isFinite(n)) return null;
  try {
    return new Intl.NumberFormat('de-DE', { style: 'currency', currency: currency || 'EUR' }).format(n);
  } catch (err) {
    return `${n.toFixed(2)} ${currency || ''}`.trim();
  }
}

function normalizePrice(v) {
  if (v == null) return null;
  if (typeof v === 'number') return { text: money(v, 'EUR'), amount: v };
  if (typeof v === 'string') {
    const n = Number(v.replace(',', '.'));
    return Number.isFinite(n) && /^[\d.,]+$/.test(v.trim()) ? { text: money(n, 'EUR'), amount: n } : { text: v, amount: null };
  }
  if (typeof v === 'object') {
    const amount = v.amount ?? v.value ?? v.price ?? null;
    const currency = v.currency_code ?? v.currencyCode ?? v.currency ?? 'EUR';
    if (amount == null) return v.text ? { text: String(v.text), amount: null } : null;
    const n = Number(amount);
    return { text: money(n, currency) || String(amount), amount: Number.isFinite(n) ? n : null };
  }
  return null;
}

function photoUrl(p) {
  if (!p) return null;
  if (typeof p === 'string') return p;
  const thumbs = Array.isArray(p.thumbnails) ? p.thumbnails : [];
  const good = thumbs
    .filter((t) => t && t.url && (!t.width || t.width >= 300))
    .sort((a, b) => (a.width || 0) - (b.width || 0))[0];
  return (good && good.url) || p.url || p.fullSizeUrl || p.full_size_url || null;
}

function normalizePhotos(v) {
  const list = Array.isArray(v) ? v : (v ? [v] : []);
  return Array.from(new Set(list.map(photoUrl).filter((u) => typeof u === 'string' && /^https?:\/\//.test(u))));
}

function parseAccessibilityLabel(label) {
  const grab = (re) => { const m = re.exec(label || ''); return m ? m[1].trim() : null; };
  return {
    brand: grab(/(?:Marke|Brand|Marque|Merk|Marca)\s*:\s*([^,.;]+)/i),
    condition: grab(/(?:Zustand|Condition|État|Staat|Condizione|Estado)\s*:\s*([^,.;]+)/i),
    size: grab(/(?:Größe|Size|Taille|Maat|Taglia|Talla)\s*:\s*([^,.;]+)/i),
  };
}

function absoluteUrl(url, origin, id) {
  if (!url) return `${origin}/items/${id}`;
  if (/^https:\/\//.test(url)) return url;
  if (/^\//.test(url)) return origin + url;
  return `${origin}/items/${id}`;
}

/* Gerenderte Seite: { id, productItem: { title, price, photos, url, itemBox } } – oder ältere Form */
export function normalizeItem(raw, origin) {
  const pi = raw.productItem || raw;
  const box = pi.itemBox || raw.itemBox || {};
  const fromLabel = parseAccessibilityLabel(box.accessibilityLabel);
  const title = String(pi.title || raw.title || '').trim();

  let brand = fromLabel.brand || pi.brandTitle || pi.brand_title || raw.brand_title || null;
  if (!brand && box.firstLine && box.firstLine !== title) brand = String(box.firstLine);

  return {
    id: String(raw.id),
    title,
    url: absoluteUrl(pi.url || pi.path || raw.url || raw.path, origin, raw.id),
    price: normalizePrice(pi.price ?? raw.price),
    total: normalizePrice(pi.totalItemPrice ?? pi.total_item_price ?? raw.total_item_price),
    photos: normalizePhotos(pi.photos ?? pi.photo ?? raw.photos ?? raw.photo),
    brand,
    size: fromLabel.size || pi.sizeTitle || pi.size_title || raw.size_title || null,
    condition: fromLabel.condition || pi.status || raw.status || null,
    category: pi.catalogTitle || pi.catalog_title || null,
    description: pi.description || null,
  };
}

/* --------------------------------------------------------------------------
   Details von der Artikelseite (Beschreibung, Kategorie, alle Fotos)
   -------------------------------------------------------------------------- */

export function extractDetailsFromHtml(html, offer) {
  const details = { description: null, category: null, photos: [] };

  const re = /<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  const blocks = [];
  let m;
  while ((m = re.exec(html)) !== null) {
    try {
      const data = JSON.parse(m[1]);
      blocks.push(...(Array.isArray(data) ? data : (data['@graph'] ? data['@graph'] : [data])));
    } catch (err) { /* überspringen */ }
  }
  for (const b of blocks) {
    const type = b && b['@type'];
    if (type === 'Product' || (Array.isArray(type) && type.includes('Product'))) {
      if (b.description) details.description = String(b.description).trim();
      if (b.image) details.photos = normalizePhotos(Array.isArray(b.image) ? b.image : [b.image]);
      if (typeof b.category === 'string') details.category = b.category;
    }
    if (type === 'BreadcrumbList' && Array.isArray(b.itemListElement)) {
      const names = b.itemListElement
        .slice()
        .sort((x, y) => (x.position || 0) - (y.position || 0))
        .map((x) => (x.name || (x.item && x.item.name) || '').trim())
        .filter(Boolean);
      const path = names.slice(1).filter((n) => n !== offer.title);
      if (path.length) details.category = path.join(' › ');
    }
  }

  if (!details.description) {
    const flight = flightFromHtml(html);
    const at = flight.indexOf('"description":"');
    if (at !== -1) {
      let k = at + 15;
      while (k < flight.length && flight.charCodeAt(k) !== 34) k += flight.charCodeAt(k) === 92 ? 2 : 1;
      try { details.description = JSON.parse(flight.slice(at + 14, k + 1)).trim(); } catch (err) { /* ignorieren */ }
    }
  }
  return details;
}
