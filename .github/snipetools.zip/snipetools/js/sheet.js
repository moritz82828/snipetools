/* ==========================================================================
   snipetools – Sheets (Panels von unten). Es ist immer höchstens eins offen.
   ========================================================================== */

let backdrop = null;
let current = null;
let closeTimer = null;

function ensureBackdrop() {
  if (!backdrop) {
    backdrop = document.getElementById('sheet-backdrop');
    backdrop.addEventListener('click', () => closeSheet());
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && current) closeSheet();
    });
  }
  return backdrop;
}

export function openSheet(sheet) {
  const bd = ensureBackdrop();
  if (current && current !== sheet) closeSheet(true);
  clearTimeout(closeTimer);
  current = sheet;

  document.body.classList.add('has-sheet');
  bd.hidden = false;
  sheet.hidden = false;
  requestAnimationFrame(() => requestAnimationFrame(() => {
    bd.classList.add('is-open');
    sheet.classList.add('is-open');
  }));
}

export function closeSheet(immediate = false) {
  if (!current) return;
  const sheet = current;
  const bd = ensureBackdrop();
  current = null;

  bd.classList.remove('is-open');
  sheet.classList.remove('is-open');
  document.body.classList.remove('has-sheet');

  const finish = () => {
    sheet.hidden = true;
    if (!current) bd.hidden = true;
  };
  if (immediate) finish();
  else closeTimer = setTimeout(finish, 400);
}

export function currentSheet() {
  return current;
}
