/* ==========================================================================
   snipetools – App
   Läuft komplett im Browser. Der Server liefert nur statische Dateien.
   ========================================================================== */

import {
  SESSION_KEY, loadAccounts, verifyPassword,
  readSession, writeSession, clearSession,
} from './auth.js';

import {
  TrackingStore, parseAmount, formatEuro, centsToInput,
  formatDate, monthLabel, todayISO, currentMonthKey, isValidISODate,
} from './store.js';

import { $, $$, el, showError, clearError } from './dom.js';
import { openSheet, closeSheet } from './sheet.js';
import { mountSnipebot, unmountSnipebot } from './snipebot.js';

/* Nur ein Tab pro Account: der zuletzt geöffnete Tab beansprucht die Sitzung. */
const TAB_ID = Date.now().toString(36) + Math.random().toString(36).slice(2);
const ACTIVE_TAB_KEY = 'snipetools.activeTab';

const state = {
  account: null,
  store: null,
  tab: 'home',
  sheet: { type: 'in', editingId: null, confirmDelete: false },
};

const ui = {
  screenLogin: $('#screen-login'),
  screenApp: $('#screen-app'),
  tabbar: $('.tabbar'),

  loginForm: $('#login-form'),
  username: $('#username'),
  password: $('#password'),
  loginButton: $('#login-button'),
  loginError: $('#login-error'),
  togglePassword: $('#toggle-password'),

  tabItems: $$('.tab-item'),
  panels: $$('.tab-panel'),

  homeName: $('#home-name'),
  homeMonth: $('#home-month'),
  dashSaldo: $('#dash-saldo'),
  dashBar: $('.dash-bar'),
  dashBarIn: $('#dash-bar-in'),
  dashIn: $('#dash-in'),
  dashOut: $('#dash-out'),
  dashEmpty: $('#dash-empty'),
  homeRecent: $('#home-recent'),

  typeButtons: $$('.type-btn'),
  history: $('#history'),

  kontoUser: $('#konto-user'),
  kontoSub: $('#konto-sub'),
  logoutButton: $('#logout-button'),

  sheet: $('#entry-sheet'),
  sheetTitle: $('#sheet-title'),
  sheetCancel: $('#sheet-cancel'),
  entryAmount: $('#entry-amount'),
  entryNote: $('#entry-note'),
  entryDate: $('#entry-date'),
  entryError: $('#entry-error'),
  entrySave: $('#entry-save'),
  entryDelete: $('#entry-delete'),

  lock: $('#lock'),
  lockUse: $('#lock-use'),
};

/* --------------------------------------------------------------------------
   Screens & Tabs
   -------------------------------------------------------------------------- */

function showScreen(name) {
  ui.screenLogin.hidden = name !== 'login';
  ui.screenApp.hidden = name !== 'app';
  ui.tabbar.hidden = name !== 'app';
  window.scrollTo(0, 0);
}

function selectTab(name) {
  state.tab = name;
  for (const item of ui.tabItems) {
    const active = item.dataset.tab === name;
    item.classList.toggle('is-active', active);
    if (active) item.setAttribute('aria-current', 'page');
    else item.removeAttribute('aria-current');
  }
  for (const panel of ui.panels) panel.hidden = panel.dataset.panel !== name;
  window.scrollTo(0, 0);
}

function enterApp(account) {
  state.account = account;
  state.store = new TrackingStore(account.username);
  renderAll();
  mountSnipebot(account.username);
  selectTab('home');
  showScreen('app');
  claimTab();
}

function leaveApp() {
  unmountSnipebot();
  state.account = null;
  state.store = null;
  closeSheet(true);
  ui.lock.hidden = true;
  resetLoginForm();
  showScreen('login');
}

/* --------------------------------------------------------------------------
   Rendering (Home, Tracking, Konto)
   -------------------------------------------------------------------------- */

function renderAll() {
  if (!state.account || !state.store) return;
  renderHome();
  renderTracking();
  renderKonto();
}

function entryRow(entry) {
  const sign = entry.type === 'in' ? '+' : '\u2212';
  const label = entry.note || (entry.type === 'in' ? 'Einnahme' : 'Ausgabe');
  return el('button', { type: 'button', class: 'entry', 'data-id': entry.id, 'aria-label': `${label}, ${formatEuro(entry.cents, { signed: true, type: entry.type })}, ${formatDate(entry.date)}. Zum Bearbeiten antippen.` },
    el('span', { class: `entry-icon ${entry.type}`, 'aria-hidden': 'true', text: sign }),
    el('span', { class: 'entry-main' },
      el('span', { class: 'entry-note', text: label }),
      el('span', { class: 'entry-date', text: formatDate(entry.date) }),
    ),
    el('span', { class: `entry-amount amount-${entry.type}`, text: formatEuro(entry.cents, { signed: true, type: entry.type }) }),
  );
}

function renderHome() {
  const { account, store } = state;
  ui.homeName.textContent = account.username;

  const month = currentMonthKey();
  const sum = store.monthSummary(month);
  ui.homeMonth.textContent = monthLabel(month);

  ui.dashSaldo.textContent = formatEuro(sum.saldoCents, { signed: true });
  ui.dashSaldo.classList.toggle('amount-in', sum.saldoCents > 0);
  ui.dashSaldo.classList.toggle('amount-out', sum.saldoCents < 0);
  ui.dashIn.textContent = formatEuro(sum.inCents);
  ui.dashOut.textContent = formatEuro(sum.outCents);

  const total = sum.inCents + sum.outCents;
  ui.dashBar.classList.toggle('is-empty', total === 0);
  ui.dashBarIn.style.width = total === 0 ? '0%' : `${Math.round((sum.inCents / total) * 100)}%`;
  ui.dashEmpty.hidden = sum.count > 0;

  const recent = store.sorted().slice(0, 3);
  ui.homeRecent.replaceChildren();
  if (recent.length === 0) {
    ui.homeRecent.append(el('p', { class: 'empty', text: 'Noch keine Buchungen. Trage unter „Tracking“ deine erste Einnahme oder Ausgabe ein.' }));
    return;
  }
  for (const entry of recent) ui.homeRecent.append(entryRow(entry));
  ui.homeRecent.append(el('button', { type: 'button', class: 'list-link', 'data-goto': 'tracking', text: 'Alle Buchungen' }));
}

function renderTracking() {
  const entries = state.store.sorted();
  ui.history.replaceChildren();

  if (entries.length === 0) {
    ui.history.append(
      el('h2', { class: 'section-title' }, el('span', { text: 'Verlauf' })),
      el('div', { class: 'card' },
        el('p', { class: 'empty', text: 'Noch keine Buchungen. Tippe auf + oder −, um deine erste Einnahme oder Ausgabe einzutragen.' })),
    );
    return;
  }

  const groups = new Map();
  for (const entry of entries) {
    const month = entry.date.slice(0, 7);
    if (!groups.has(month)) groups.set(month, []);
    groups.get(month).push(entry);
  }

  for (const [month, list] of groups) {
    const sum = state.store.monthSummary(month);
    const card = el('div', { class: 'card list' });
    for (const entry of list) card.append(entryRow(entry));
    ui.history.append(
      el('h2', { class: 'section-title' },
        el('span', { text: monthLabel(month) }),
        el('span', { class: 'section-meta', text: formatEuro(sum.saldoCents, { signed: true }) }),
      ),
      card,
    );
  }
}

function renderKonto() {
  const sub = String(state.account.subscription || 'free');
  ui.kontoUser.textContent = state.account.username;
  ui.kontoSub.textContent = sub.charAt(0).toUpperCase() + sub.slice(1);
}

/* --------------------------------------------------------------------------
   Sheet: Einnahme / Ausgabe erfassen oder bearbeiten
   -------------------------------------------------------------------------- */

function openEntrySheet(type, entry = null) {
  state.sheet = { type, editingId: entry ? entry.id : null, confirmDelete: false };
  clearError(ui.entryError);

  ui.sheetTitle.textContent = entry
    ? (type === 'in' ? 'Einnahme bearbeiten' : 'Ausgabe bearbeiten')
    : (type === 'in' ? 'Einnahme' : 'Ausgabe');

  ui.entryAmount.value = entry ? centsToInput(entry.cents) : '';
  ui.entryNote.value = entry ? entry.note : '';
  ui.entryDate.value = entry ? entry.date : todayISO();

  ui.entrySave.className = `btn ${type === 'in' ? 'btn-in' : 'btn-out'}`;
  ui.entryDelete.hidden = !entry;
  ui.entryDelete.textContent = 'Eintrag löschen';

  openSheet(ui.sheet);
  setTimeout(() => ui.entryAmount.focus({ preventScroll: true }), 420);
}

function saveEntry(event) {
  event.preventDefault();
  clearError(ui.entryError);
  const cents = parseAmount(ui.entryAmount.value);
  if (cents === null) {
    showError(ui.entryError, 'Bitte einen Betrag größer als 0 eingeben, z. B. 12,50.');
    ui.entryAmount.focus();
    return;
  }
  const date = ui.entryDate.value;
  if (!isValidISODate(date)) {
    showError(ui.entryError, 'Bitte ein gültiges Datum wählen.');
    ui.entryDate.focus();
    return;
  }

  const data = { type: state.sheet.type, cents, note: ui.entryNote.value, date };
  if (state.sheet.editingId) state.store.update(state.sheet.editingId, data);
  else state.store.add(data);

  renderAll();
  closeSheet();
}

function deleteEntry() {
  if (!state.sheet.editingId) return;
  if (!state.sheet.confirmDelete) {
    state.sheet.confirmDelete = true;
    ui.entryDelete.textContent = 'Wirklich löschen? Erneut antippen';
    return;
  }
  state.store.remove(state.sheet.editingId);
  renderAll();
  closeSheet();
}

/* --------------------------------------------------------------------------
   Login
   -------------------------------------------------------------------------- */

function setLoading(isLoading) {
  ui.loginButton.disabled = isLoading;
  ui.loginButton.classList.toggle('is-loading', isLoading);
  ui.username.readOnly = isLoading;
  ui.password.readOnly = isLoading;
}

function setPasswordVisible(visible) {
  ui.password.type = visible ? 'text' : 'password';
  ui.togglePassword.setAttribute('aria-pressed', String(visible));
  ui.togglePassword.setAttribute('aria-label', visible ? 'Passwort verbergen' : 'Passwort anzeigen');
}

function resetLoginForm() {
  ui.loginForm.reset();
  setPasswordVisible(false);
  clearError(ui.loginError);
}

async function login(event) {
  event.preventDefault();
  clearError(ui.loginError);

  const username = ui.username.value.trim();
  const password = ui.password.value;

  if (!username || !password) {
    showError(ui.loginError, 'Bitte Benutzername und Passwort eingeben.');
    return;
  }

  setLoading(true);
  try {
    const accounts = await loadAccounts();
    const account = accounts.get(username.toLowerCase());
    const ok = account ? await verifyPassword(password, account.hash) : false;

    if (!ok) {
      showError(ui.loginError, 'Benutzername oder Passwort ist falsch.');
      ui.password.value = '';
      ui.password.focus({ preventScroll: true });
      return;
    }

    writeSession(account);          // ersetzt eine evtl. vorhandene Sitzung – es gibt nur eine
    resetLoginForm();
    enterApp(account);
  } catch (err) {
    showError(ui.loginError, err.message || 'Login fehlgeschlagen.');
  } finally {
    setLoading(false);
  }
}

function logout() {
  clearSession();
  leaveApp();
}

/* --------------------------------------------------------------------------
   Nur ein Tab pro Account
   -------------------------------------------------------------------------- */

function claimTab() {
  try { localStorage.setItem(ACTIVE_TAB_KEY, TAB_ID); } catch (err) { /* ignorieren */ }
}

window.addEventListener('storage', (event) => {
  if (!state.account) return;

  // Ein anderer Tab hat die Sitzung übernommen (Login oder Aufruf dort)
  if (event.key === ACTIVE_TAB_KEY && event.newValue && event.newValue !== TAB_ID) {
    unmountSnipebot();
    closeSheet(true);
    ui.lock.hidden = false;
    return;
  }
  // In einem anderen Tab wurde ausgeloggt
  if (event.key === SESSION_KEY && event.newValue === null) {
    leaveApp();
  }
});

/* --------------------------------------------------------------------------
   Ereignisse
   -------------------------------------------------------------------------- */

ui.togglePassword.addEventListener('click', () => {
  setPasswordVisible(ui.password.type === 'password');
  ui.password.focus({ preventScroll: true });
});

ui.loginForm.addEventListener('submit', login);
ui.logoutButton.addEventListener('click', logout);

for (const item of ui.tabItems) {
  item.addEventListener('click', () => selectTab(item.dataset.tab));
}

for (const button of ui.typeButtons) {
  button.addEventListener('click', () => openEntrySheet(button.dataset.type));
}

// Buchung antippen → bearbeiten; „Alle Buchungen“ → Tracking-Tab
ui.screenApp.addEventListener('click', (event) => {
  const link = event.target.closest('[data-goto]');
  if (link) { selectTab(link.dataset.goto); return; }

  const row = event.target.closest('.entry');
  if (row && state.store) {
    const entry = state.store.get(row.dataset.id);
    if (entry) openEntrySheet(entry.type, entry);
  }
});

ui.sheet.addEventListener('submit', saveEntry);
ui.sheetCancel.addEventListener('click', () => closeSheet());
ui.entryDelete.addEventListener('click', deleteEntry);

ui.lockUse.addEventListener('click', () => {
  ui.lock.hidden = true;
  init();
});

/* --------------------------------------------------------------------------
   Start: Sitzung gegen accounts.txt prüfen.
   Account entfernt oder Passwort geändert → Sitzung endet.
   -------------------------------------------------------------------------- */

async function init() {
  const session = readSession();
  if (!session) {
    showScreen('login');
    return;
  }

  try {
    const accounts = await loadAccounts();
    const account = accounts.get(session.username.toLowerCase());

    if (!account || account.hash !== session.hash) {
      clearSession();
      leaveApp();
      showError(ui.loginError, 'Deine Sitzung ist abgelaufen. Bitte melde dich erneut an.');
      return;
    }

    writeSession(account); // Subscription aktualisieren
    enterApp(account);
  } catch (err) {
    // accounts.txt gerade nicht erreichbar: letzten bekannten Stand verwenden
    enterApp({ username: session.username, subscription: session.subscription, hash: session.hash });
  }
}

init();
