// Baut das Snipebot-Lesezeichen: bookmarklet/bot.js (+ vinted-core.js) → snipetools/inject/snipebot.min.js
// Aufruf:  npm install && node build.mjs
import { build } from 'esbuild';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

const out = '../snipetools/inject/snipebot.min.js';
mkdirSync('../snipetools/inject', { recursive: true });

await build({
  entryPoints: ['bookmarklet/bot.js'],
  bundle: true,
  minify: true,
  format: 'iife',
  target: ['safari15', 'chrome100', 'firefox100'],
  charset: 'utf8',
  legalComments: 'none',
  outfile: out,
});

const code = readFileSync(out, 'utf8').trim();
writeFileSync(out, code + '\n');
// gleiche Kodierung wie in snipetools/js/snipebot.js (bookmarkletFrom)
const bookmarklet = 'javascript:' + code.replace(/[%#\s]|[^\x00-\x7f]/g, (c) => encodeURIComponent(c));
console.log(`snipebot.min.js: ${code.length} Zeichen, Lesezeichen: ${bookmarklet.length} Zeichen`);
