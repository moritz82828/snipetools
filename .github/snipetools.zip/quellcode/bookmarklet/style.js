/* Styles des Snipebot-Overlays – liegen im Shadow DOM, Vinted bleibt unberührt */
export const CSS = `
:host {
  all: initial;
  --font: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Helvetica Neue", "Segoe UI", Roboto, system-ui, sans-serif;
  --bg: #f2f2f7; --card: #ffffff; --label: #000; --label-2: rgba(60,60,67,.6); --label-3: rgba(60,60,67,.3);
  --sep: rgba(60,60,67,.29); --fill: rgba(120,120,128,.12);
  --blue: #007aff; --green: #34c759; --red: #ff3b30;
  --green-fill: rgba(52,199,89,.16); --red-fill: rgba(255,59,48,.14); --blue-fill: rgba(0,122,255,.12);
  --bar: rgba(255,255,255,.82); --bar-border: rgba(255,255,255,.75);
  --shadow: 0 18px 50px rgba(0,0,0,.22);
  position: fixed; inset: 0; z-index: 2147483647; pointer-events: none;
  font: 400 17px/1.35 var(--font); color: var(--label);
  -webkit-font-smoothing: antialiased; -webkit-text-size-adjust: 100%;
}
@media (prefers-color-scheme: dark) {
  :host {
    --bg: #000; --card: #1c1c1e; --label: #fff; --label-2: rgba(235,235,245,.6); --label-3: rgba(235,235,245,.3);
    --sep: rgba(84,84,88,.65); --fill: rgba(120,120,128,.24);
    --blue: #0a84ff; --green: #30d158; --red: #ff453a;
    --green-fill: rgba(48,209,88,.2); --red-fill: rgba(255,69,58,.2); --blue-fill: rgba(10,132,255,.2);
    --bar: rgba(28,28,30,.82); --bar-border: rgba(255,255,255,.1);
    --shadow: 0 18px 50px rgba(0,0,0,.6);
  }
}
*, *::before, *::after { box-sizing: border-box; }
[hidden] { display: none !important; }
button { font: inherit; color: inherit; cursor: pointer; -webkit-tap-highlight-color: transparent; touch-action: manipulation; }
p { margin: 0; }

/* ---------- Panel ---------- */
.panel {
  pointer-events: auto;
  position: absolute; inset: 0;
  display: flex; flex-direction: column;
  background: var(--bg);
}
@media (min-width: 760px) {
  .panel { inset: 12px 12px 12px auto; width: 430px; border-radius: 24px; box-shadow: var(--shadow); overflow: hidden; }
}
.head {
  display: flex; align-items: center; gap: 6px;
  padding: calc(env(safe-area-inset-top, 0px) + 10px) 12px 8px 20px;
  background: var(--bg);
}
.brand { flex: 1; font-size: 22px; font-weight: 700; letter-spacing: -.3px; }
.icon {
  width: 38px; height: 38px; display: grid; place-items: center; padding: 0;
  border: 0; border-radius: 50%; background: var(--fill); color: var(--label-2);
}
.icon:active { transform: scale(.92); }
.scroll {
  flex: 1; overflow-y: auto; -webkit-overflow-scrolling: touch; overscroll-behavior: contain;
  padding: 6px 16px calc(env(safe-area-inset-bottom, 0px) + 24px);
}

.card { background: var(--card); border-radius: 20px; }
.card + .card, .site-note + .card, .card + .site-note { margin-top: 12px; }

.status { display: flex; align-items: center; gap: 12px; padding: 14px 14px 14px 16px; }
.status-text { flex: 1; min-width: 0; }
.state { font-size: 17px; font-weight: 600; }
.detail { margin-top: 1px; font-size: 13px; color: var(--label-2); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.dot { flex: none; width: 12px; height: 12px; border-radius: 50%; background: var(--label-3); }
.dot.is-on { background: var(--green); box-shadow: 0 0 0 4px var(--green-fill); }
.dot.is-error { background: var(--red); box-shadow: 0 0 0 4px var(--red-fill); }

.pill {
  flex: none; min-height: 36px; padding: 0 16px; border: 0; border-radius: 999px;
  color: #fff; font-size: 15px; font-weight: 600;
}
.pill:active { transform: scale(.96); }
.pill-blue { background: var(--blue); }
.pill-plain { margin-top: 10px; background: var(--fill); color: var(--blue); }
.diag-text {
  display: block; width: 100%; height: 140px; margin-top: 10px; padding: 8px 10px;
  border: 0; border-radius: 10px; background: var(--fill); color: var(--label-2);
  font: 11px/1.4 ui-monospace, "SF Mono", Menlo, monospace; resize: none;
}
.pill-red { background: var(--red); }

.site-note {
  margin-top: 12px; padding: 12px 16px; border-radius: 16px;
  background: var(--blue-fill); color: var(--label); font-size: 14px; line-height: 1.4;
}

.filter { padding: 12px 16px 14px; }
.filter-title { font-size: 13px; font-weight: 500; color: var(--label-2); }
.filter-text { margin-top: 2px; font-size: 15px; line-height: 1.4; }
.link {
  margin-top: 8px; padding: 0; border: 0; background: none;
  color: var(--blue); font-size: 15px; font-weight: 500; text-align: left;
}

.message { margin-top: 12px; padding: 14px 16px; color: var(--label-2); font-size: 15px; line-height: 1.45; }
.message p + p { margin-top: 4px; }
.msg-title { color: var(--label); font-size: 17px; font-weight: 600; }
.message.is-error .msg-title { color: var(--red); }

/* ---------- Kacheln ---------- */
.grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; margin-top: 14px; }
.offer {
  display: flex; flex-direction: column; overflow: hidden; border-radius: 18px;
  background: var(--card); color: var(--label); text-decoration: none;
}
.offer:active { transform: scale(.98); }
.offer.is-new { box-shadow: 0 0 0 2px var(--green); }
.media { position: relative; aspect-ratio: 3 / 4; background: var(--fill); }
.photos { display: flex; height: 100%; overflow-x: auto; scroll-snap-type: x mandatory; scrollbar-width: none; }
.photos::-webkit-scrollbar { display: none; }
.photos img, .nophoto { flex: none; width: 100%; height: 100%; object-fit: cover; scroll-snap-align: start; display: block; }
.nophoto { display: grid; place-items: center; color: var(--label-3); }
.badge, .count {
  position: absolute; top: 8px; padding: 3px 8px; border-radius: 999px;
  font-size: 11px; font-weight: 700; line-height: 1.3; color: #fff;
}
.badge { left: 8px; background: var(--green); }
.count { right: 8px; background: rgba(0,0,0,.55); }
.body { padding: 10px 12px 12px; }
.price-row { display: flex; align-items: baseline; gap: 6px; flex-wrap: wrap; }
.price { font-size: 17px; font-weight: 700; font-variant-numeric: tabular-nums; }
.total { font-size: 11px; color: var(--label-3); }
.title {
  margin-top: 2px; font-size: 15px; line-height: 1.3;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}
.meta, .cat { margin-top: 3px; font-size: 13px; color: var(--label-2); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.cat { color: var(--label-3); }
.desc {
  margin-top: 6px; font-size: 13px; line-height: 1.4; color: var(--label-2);
  display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;
}
.foot { margin: 18px 8px 0; text-align: center; font-size: 12px; color: var(--label-3); }

/* ---------- minimiert ---------- */
.mini {
  pointer-events: auto;
  position: absolute; left: 50%; bottom: calc(env(safe-area-inset-bottom, 0px) + 16px);
  transform: translateX(-50%);
  display: flex; align-items: center; gap: 10px;
  max-width: calc(100% - 32px); min-height: 48px; padding: 0 18px 0 16px;
  border: 1px solid var(--bar-border); border-radius: 999px;
  background: var(--bar); -webkit-backdrop-filter: blur(20px) saturate(180%); backdrop-filter: blur(20px) saturate(180%);
  box-shadow: var(--shadow);
  font-size: 14px; font-weight: 600;
}
.mini-text { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
`;
