/* ==========================================================================
   snipetools – Snipebot (Lesezeichen)
   Wird per Lesezeichen in einem Vinted-Tab gestartet. Alle Anfragen gehen
   von dort aus – gleiche Seite, eigene Vinted-Sitzung, kein Server.
   Angebote liegen nur im Speicher. Ist der Tab von snipetools.de geöffnet
   worden, gehen die Angebote zusätzlich per Nachricht dorthin.
   Gebündelt mit quellcode/build.mjs zu snipetools/inject/snipebot.min.js.
   ========================================================================== */

import {
  BOT_VERSION, DEFAULT_FILTERS, DEFAULT_BOT_SETTINGS, catalogQuery, filtersFromSearch,
  sameFilters, describeFilters, decodeConfig, offersFromData, offersFromFlight,
  offersFromHtmlDom, offersFromDocument, describeHtml,
  extractDetailsFromHtml, domainFromHost, VINTED_ORIGIN_RE,
} from '../../snipetools/js/vinted-core.js';

import { CSS } from './style.js';

(() => {
  /* ---------- schon aktiv? Dann nur das Panel zeigen ---------- */
  if (window.__snipetoolsBot) {
    window.__snipetoolsBot.expand();
    return;
  }

  if (!VINTED_ORIGIN_RE.test(location.origin)) {
    alert('snipetools: Bitte das Lesezeichen auf einer Vinted-Seite antippen (z. B. vinted.de).');
    return;
  }

  const CONFIG_KEY = 'snipetools.bot.config';
  const MAX_DETAILS_PER_RUN = 6;
  const SEEN_LIMIT = 5000;
  const origin = location.origin;
  const domain = domainFromHost(location.hostname);

  /* ---------------------------------------------------------------------
     Konfiguration: Adresse (#snipetools=…) → Sitzungsspeicher → aktuelle Suche
     --------------------------------------------------------------------- */

  function readConfig() {
    const m = /[#&]snipetools=([A-Za-z0-9_-]+)/.exec(location.hash);
    if (m) {
      const cfg = decodeConfig(m[1]);
      try {
        const clean = location.hash.replace(/[#&]?snipetools=[A-Za-z0-9_-]+/, '');
        history.replaceState(history.state, '', location.pathname + location.search + (clean && clean !== '#' ? clean : ''));
      } catch (err) { /* Adresse bleibt dann so */ }
      if (cfg && cfg.v === 1) return cfg;
    }
    try {
      const raw = sessionStorage.getItem(CONFIG_KEY);
      if (raw) {
        const cfg = JSON.parse(raw);
        if (cfg && cfg.v === 1) return cfg;
      }
    } catch (err) { /* kein Speicher */ }
    return null;
  }

  function saveConfig() {
    try {
      sessionStorage.setItem(CONFIG_KEY, JSON.stringify({ v: 1, origin: bot.siteOrigin, filters: bot.filters, settings: bot.settings }));
    } catch (err) { /* kein Speicher */ }
  }

  const onCatalogPage = () => /^\/catalog/.test(location.pathname) && location.search.length > 1;

  const initial = readConfig();

  const bot = {
    filters: initial ? { ...DEFAULT_FILTERS, ...initial.filters }
      : onCatalogPage() ? filtersFromSearch(location.search) : { ...DEFAULT_FILTERS },
    settings: { ...DEFAULT_BOT_SETTINGS, ...(initial && initial.settings) },
    siteOrigin: initial && typeof initial.origin === 'string' ? initial.origin : null,
    site: null,          // Fenster von snipetools (opener), wenn verbunden
    siteConnected: false,
    running: false,
    busy: false,
    timer: null,
    firstRun: true,
    offers: [],
    seen: new Set(),
    lastRun: null,
    lastNewCount: 0,
    lastError: null,
    lastStatus: null,
    strategy: null,      // Weg, der zuletzt funktioniert hat
    diag: null,          // Befund der letzten Suche (für „Diagnose kopieren“)
    expanded: true,
    audio: null,
    titleBase: null,
  };

  /* ---------------------------------------------------------------------
     Netzwerk – nur die eigene Vinted-Seite
     --------------------------------------------------------------------- */

  function statusMessage(status) {
    if (status === 403) return 'Vinted hat die Anfrage abgewiesen (403). Seite neu laden, ggf. die Sicherheitsprüfung lösen und das Lesezeichen erneut antippen.';
    if (status === 429) return 'Zu viele Anfragen (429). Bitte ein längeres Intervall einstellen.';
    if (status === 401) return 'Vinted verlangt eine Anmeldung (401). Seite neu laden und erneut versuchen.';
    return `Vinted hat mit HTTP ${status} geantwortet.`;
  }

  async function getText(url, headers = {}) {
    const res = await fetch(url, {
      credentials: 'include',
      headers: { Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', ...headers },
    });
    bot.lastStatus = { status: res.status, url };
    const text = await res.text();
    if (!res.ok) throw Object.assign(new Error(statusMessage(res.status)), { status: res.status });
    let finalPath = null;
    try { finalPath = new URL(res.url).pathname; } catch (err) { /* ignorieren */ }
    return { text, type: res.headers.get('content-type') || '', finalPath };
  }

  /* Weg 4: Seite unsichtbar im Tab laden und die fertig gerenderten Karten lesen.
     Hilft, wenn Vinted die Angebote erst im Browser nachlädt. */
  function viaFrame(path) {
    return new Promise((resolve, reject) => {
      const frame = document.createElement('iframe');
      frame.setAttribute('aria-hidden', 'true');
      frame.setAttribute('tabindex', '-1');
      for (const [k, v] of Object.entries({
        position: 'fixed', left: '-12000px', top: '0', width: '1280px', height: '1600px',
        border: '0', opacity: '0', 'pointer-events': 'none',
      })) frame.style.setProperty(k, v, 'important');

      let done = false;
      let poll = null;
      const finish = (fn, val) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        clearInterval(poll);
        frame.remove();
        fn(val);
      };
      const timer = setTimeout(() => finish(reject, new Error('Zeitüberschreitung beim Laden im Hintergrund.')), 25000);

      frame.addEventListener('load', () => {
        let doc;
        try { doc = frame.contentDocument; } catch (err) { doc = null; }
        if (!doc || !doc.location || doc.location.href === 'about:blank') {
          finish(reject, new Error('Vinted erlaubt das Laden im Hintergrund nicht.'));
          return;
        }
        let tries = 0;
        poll = setInterval(() => {
          tries++;
          let offers = [];
          try { offers = offersFromDocument(doc, origin); } catch (err) { offers = []; }
          if (offers.length || tries > 30) finish(resolve, offers);
        }, 500);
      });
      frame.src = path;
      (document.body || document.documentElement).append(frame);
    });
  }

  const STRATEGIES = ['data', 'cards', 'flight', 'frame'];

  async function runStrategy(name, path, page, diag) {
    if (name === 'data' || name === 'cards') {
      if (!page.html) {
        const r = await getText(path);
        page.html = r.text;
        diag.page = { status: bot.lastStatus.status, type: r.type, finalPath: r.finalPath, ...describeHtml(r.text) };
      }
      return name === 'data' ? offersFromData(page.html, origin) : offersFromHtmlDom(page.html, origin);
    }
    if (name === 'flight') {
      const sep = path.includes('?') ? '&' : '?';
      const r = await getText(`${path}${sep}_rsc=${Date.now().toString(36)}`, { RSC: '1', Accept: 'text/x-component' });
      diag.flight = { type: r.type, bytes: r.text.length };
      return offersFromFlight(r.text, origin);
    }
    return viaFrame(path);
  }

  async function search() {
    const path = `/catalog?${catalogQuery(domain, bot.filters)}`;
    const diag = { v: BOT_VERSION, at: new Date().toISOString(), path, ua: navigator.userAgent.slice(0, 120), tried: {} };
    const page = { html: null };
    const order = bot.strategy ? [bot.strategy, ...STRATEGIES.filter((s) => s !== bot.strategy)] : STRATEGIES;

    let lastErr = null;
    for (const name of order) {
      try {
        const offers = await runStrategy(name, path, page, diag);
        diag.tried[name] = offers.length;
        if (offers.length) {
          bot.strategy = name;
          bot.diag = { ...diag, used: name };
          return offers.slice(0, Number(bot.settings.perPage) || 40);
        }
      } catch (err) {
        diag.tried[name] = `Fehler: ${err.message}`;
        lastErr = err;
        if (err.status === 403 || err.status === 429) break; // Vinted blockt – nicht weiter anfragen
      }
    }
    bot.strategy = null;
    bot.diag = diag;
    if (lastErr && (lastErr.status === 403 || lastErr.status === 429 || lastErr.status === 401)) throw lastErr;
    const err = new Error('Die Vinted-Seite kam an, aber auf keinem Weg ließen sich Angebote auslesen. Bitte „Diagnose kopieren“ und an den Entwickler schicken.');
    throw err;
  }

  /* ---------------------------------------------------------------------
     Suchlauf
     --------------------------------------------------------------------- */

  function start() {
    if (bot.running) return;
    bot.running = true;
    bot.lastError = null;
    ensureAudio();
    render();
    report();
    tick();
  }

  function stop() {
    bot.running = false;
    clearTimeout(bot.timer);
    bot.timer = null;
    render();
    report();
  }

  function scheduleNext() {
    clearTimeout(bot.timer);
    if (!bot.running) return;
    bot.timer = setTimeout(tick, Math.max(10, Number(bot.settings.intervalSec) || 30) * 1000);
  }

  async function tick() {
    if (!bot.running || bot.busy) return;
    bot.busy = true;
    render();
    try {
      const items = await search();
      const fresh = [];
      for (const o of items) {
        o.isNew = !bot.firstRun && !bot.seen.has(o.id);
        if (o.isNew) fresh.push(o);
      }
      for (const o of items) bot.seen.add(o.id);
      if (bot.seen.size > SEEN_LIMIT) bot.seen = new Set(Array.from(bot.seen).slice(-SEEN_LIMIT / 2));

      const known = new Map(bot.offers.map((o) => [o.id, o]));
      bot.offers = items.map((o) => {
        const old = known.get(o.id);
        return old && old.detailsLoaded
          ? { ...o, description: old.description, category: old.category, photos: old.photos, detailsLoaded: true }
          : o;
      });
      bot.firstRun = false;
      bot.lastNewCount = fresh.length;
      bot.lastError = null;
      bot.lastRun = Date.now();
      render();
      renderGrid();
      report(true);
      if (fresh.length) alertNew(fresh.length);
      if (bot.settings.details) await loadDetails();
    } catch (err) {
      bot.lastError = err && err.message ? err.message : String(err);
      bot.lastRun = Date.now();
      render();
      report();
    } finally {
      bot.busy = false;
      render();
      report();
      scheduleNext();
    }
  }

  async function loadDetails() {
    const todo = bot.offers.filter((o) => !o.detailsLoaded).slice(0, MAX_DETAILS_PER_RUN);
    for (const offer of todo) {
      if (!bot.running) return;
      try {
        const d = extractDetailsFromHtml((await getText(new URL(offer.url).pathname)).text, offer);
        offer.description = d.description || offer.description;
        offer.category = d.category || offer.category;
        if (d.photos.length) offer.photos = d.photos;
      } catch (err) { /* Details sind optional */ }
      offer.detailsLoaded = true;
      renderGrid();
      report(true);
      await new Promise((r) => setTimeout(r, 400));
    }
  }

  function applyFilters(filters) {
    const next = { ...DEFAULT_FILTERS, ...filters };
    if (sameFilters(next, bot.filters)) return;
    bot.filters = next;
    bot.offers = [];
    bot.seen = new Set();
    bot.firstRun = true;
    bot.lastNewCount = 0;
    saveConfig();
    render();
    renderGrid();
    if (bot.running) { clearTimeout(bot.timer); tick(); } else report(true);
  }

  /* ---------------------------------------------------------------------
     Hinweise bei neuen Angeboten (Ton, Titel)
     --------------------------------------------------------------------- */

  function ensureAudio() {
    if (!bot.settings.sound || bot.audio) return;
    try { bot.audio = new (window.AudioContext || window.webkitAudioContext)(); } catch (err) { bot.audio = null; }
  }

  function alertNew(count) {
    if (document.hidden) {
      if (bot.titleBase == null) bot.titleBase = document.title;
      document.title = `(${count}) Neu – ${bot.titleBase}`;
    }
    if (!bot.settings.sound || !bot.audio) return;
    try {
      const ctx = bot.audio;
      if (ctx.state === 'suspended') ctx.resume();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = 880;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.25);
      osc.connect(gain).connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.3);
    } catch (err) { /* kein Ton */ }
  }

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && bot.titleBase != null) {
      document.title = bot.titleBase;
      bot.titleBase = null;
    }
  });

  /* ---------------------------------------------------------------------
     Verbindung zu snipetools (nur wenn snipetools diesen Tab geöffnet hat)
     --------------------------------------------------------------------- */

  function siteWindow() {
    try { return window.opener && !window.opener.closed ? window.opener : null; } catch (err) { return null; }
  }

  function post(msg) {
    const w = siteWindow();
    if (!w || !bot.siteOrigin) return;
    try {
      w.postMessage({ source: 'snipetools-bot', version: BOT_VERSION, ...msg }, bot.siteOrigin);
    } catch (err) { /* snipetools nicht erreichbar */ }
  }

  function statusPayload() {
    return {
      running: bot.running,
      busy: bot.busy,
      intervalSec: bot.settings.intervalSec,
      lastRun: bot.lastRun,
      lastNewCount: bot.lastNewCount,
      error: bot.lastError,
      lastStatus: bot.lastStatus,
      strategy: bot.strategy,
      diag: bot.diag,
      filters: bot.filters,
      domain,
      count: bot.offers.length,
    };
  }

  function report(withOffers = false) {
    post({ type: 'status', status: statusPayload(), ...(withOffers ? { offers: bot.offers } : {}) });
  }

  window.addEventListener('message', (event) => {
    const msg = event.data;
    if (!msg || msg.source !== 'snipetools-site') return;
    const w = siteWindow();
    // Nur das Fenster, das diesen Tab geöffnet hat, darf steuern
    if (!w || event.source !== w) return;
    if (bot.siteOrigin && event.origin !== bot.siteOrigin) return;

    if (msg.type === 'config' && msg.config) {
      bot.siteOrigin = event.origin;
      bot.siteConnected = true;
      if (msg.config.settings) bot.settings = { ...DEFAULT_BOT_SETTINGS, ...msg.config.settings };
      saveConfig();
      if (msg.config.filters) applyFilters(msg.config.filters);
      if (msg.config.autostart && !bot.running) start();
      // Am PC zeigt snipetools die Angebote – hier reicht die kleine Leiste.
      // Auf Touch-Geräten bleibt das Panel offen (snipetools-Tab ruht im Hintergrund).
      if (!matchMedia('(pointer: coarse)').matches) bot.expanded = false;
      render();
      report(true);
      return;
    }
    if (msg.type === 'start') { start(); return; }
    if (msg.type === 'stop') { stop(); return; }
    if (msg.type === 'ping') report(true);
  });

  // Hallo an snipetools – ohne Daten, deshalb an jedes Ziel erlaubt
  function hello() {
    const w = siteWindow();
    if (!w) return;
    try { w.postMessage({ source: 'snipetools-bot', type: 'hello', version: BOT_VERSION, domain }, bot.siteOrigin || '*'); } catch (err) { /* ignorieren */ }
  }

  setInterval(() => { if (bot.siteConnected) report(); }, 15000);

  /* ---------------------------------------------------------------------
     Oberfläche (Shadow DOM, damit Vinted-Styles nichts verändern)
     --------------------------------------------------------------------- */

  function h(tag, props, ...children) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k === 'on') for (const [ev, fn] of Object.entries(v)) node.addEventListener(ev, fn);
      else node.setAttribute(k, v === true ? '' : v);
    }
    for (const c of children) if (c != null && c !== false) node.append(typeof c === 'string' ? document.createTextNode(c) : c);
    return node;
  }

  function svg(paths, size = 20) {
    const ns = 'http://www.w3.org/2000/svg';
    const s = document.createElementNS(ns, 'svg');
    for (const [k, v] of Object.entries({ viewBox: '0 0 24 24', width: size, height: size, fill: 'none', stroke: 'currentColor', 'stroke-width': '2', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true' })) s.setAttribute(k, v);
    for (const d of [].concat(paths)) {
      const p = document.createElementNS(ns, 'path');
      p.setAttribute('d', d);
      s.append(p);
    }
    return s;
  }

  const host = document.createElement('div');
  host.id = 'snipetools-bot';
  const root = host.attachShadow({ mode: 'open' });

  // Styles: bevorzugt als konstruiertes Stylesheet (greift auch bei strenger CSP)
  try {
    const sheet = new CSSStyleSheet();
    sheet.replaceSync(CSS);
    root.adoptedStyleSheets = [sheet];
  } catch (err) {
    root.append(h('style', { text: CSS }));
  }

  const ui = {};

  ui.dot = h('span', { class: 'dot' });
  ui.state = h('div', { class: 'state' });
  ui.detail = h('div', { class: 'detail' });
  ui.toggle = h('button', { type: 'button', class: 'pill', on: { click: () => (bot.running ? stop() : start()) } });
  ui.filterText = h('div', { class: 'filter-text' });
  ui.useSearch = h('button', {
    type: 'button', class: 'link',
    on: { click: () => { applyFilters(filtersFromSearch(location.search)); if (!bot.running) start(); } },
    text: 'Aktuelle Vinted-Suche verwenden',
  });
  ui.message = h('div', { class: 'message' });
  ui.grid = h('div', { class: 'grid' });
  ui.siteNote = h('div', { class: 'site-note' });

  ui.panel = h('section', { class: 'panel', role: 'dialog', 'aria-label': 'snipetools Snipebot' },
    h('header', { class: 'head' },
      h('div', { class: 'brand', text: 'snipetools' }),
      h('button', { type: 'button', class: 'icon', 'aria-label': 'Minimieren', on: { click: () => setExpanded(false) } }, svg('M6 9l6 6 6-6')),
      h('button', { type: 'button', class: 'icon', 'aria-label': 'Snipebot beenden', on: { click: destroy } }, svg(['M6 6l12 12', 'M18 6L6 18'])),
    ),
    h('div', { class: 'scroll' },
      h('div', { class: 'card status' },
        ui.dot,
        h('div', { class: 'status-text' }, ui.state, ui.detail),
        ui.toggle,
      ),
      ui.siteNote,
      h('div', { class: 'card filter' },
        h('div', { class: 'filter-title', text: 'Filter' }),
        ui.filterText,
        ui.useSearch,
      ),
      ui.message,
      ui.grid,
      h('p', { class: 'foot', text: `Angebote werden nur angezeigt, nicht gespeichert. Snipebot v${BOT_VERSION}` }),
    ),
  );

  ui.pillDot = h('span', { class: 'dot' });
  ui.pillText = h('span', { class: 'mini-text' });
  ui.mini = h('button', { type: 'button', class: 'mini', 'aria-label': 'snipetools öffnen', on: { click: () => setExpanded(true) } },
    ui.pillDot, ui.pillText,
  );

  root.append(ui.panel, ui.mini);
  (document.body || document.documentElement).append(host);

  async function copyDiag(event) {
    const btn = event.currentTarget;
    const text = JSON.stringify(bot.diag, null, 2);
    let ok = false;
    try { await navigator.clipboard.writeText(text); ok = true; } catch (err) { ok = false; }
    if (!ok) {
      const ta = h('textarea', { readonly: true, class: 'diag-text' });
      ta.value = text;
      btn.replaceWith(ta);
      ta.focus();
      ta.select();
      try { ok = document.execCommand('copy'); } catch (err) { ok = false; }
      return;
    }
    btn.textContent = 'Kopiert';
  }

  function setExpanded(v) {
    bot.expanded = v;
    render();
  }

  function timeLabel(ts) {
    return new Date(ts).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  function intervalLabel(sec) {
    return sec >= 60 ? `${Math.round(sec / 60)} min` : `${sec} s`;
  }

  function render() {
    ui.panel.hidden = !bot.expanded;
    ui.mini.hidden = bot.expanded;

    const dotClass = 'dot ' + (bot.running ? (bot.lastError ? 'is-error' : 'is-on') : 'is-off');
    ui.dot.className = dotClass;
    ui.pillDot.className = dotClass;

    ui.state.textContent = bot.running ? (bot.busy ? 'Sucht …' : 'Läuft') : 'Gestoppt';
    const parts = [`alle ${intervalLabel(bot.settings.intervalSec)}`];
    if (bot.lastRun) parts.push(`zuletzt ${timeLabel(bot.lastRun)}`);
    else parts.push('noch keine Suche');
    if (bot.running && bot.lastNewCount) parts.push(`${bot.lastNewCount} neu`);
    ui.detail.textContent = parts.join(' · ');
    ui.toggle.textContent = bot.running ? 'Stopp' : 'Start';
    ui.toggle.className = 'pill ' + (bot.running ? 'pill-red' : 'pill-blue');

    const count = bot.offers.length;
    const pill = [bot.running ? 'Läuft' : 'Gestoppt'];
    if (count) pill.push(`${count} Angebote`);
    if (bot.lastNewCount) pill.push(`${bot.lastNewCount} neu`);
    if (bot.siteConnected) pill.push('in snipetools');
    ui.pillText.textContent = 'snipetools · ' + pill.join(' · ');

    ui.filterText.textContent = describeFilters(bot.filters);
    ui.useSearch.hidden = !(onCatalogPage() && !sameFilters(filtersFromSearch(location.search), bot.filters));

    ui.siteNote.hidden = !bot.siteConnected;
    ui.siteNote.textContent = 'Verbunden mit snipetools – die Angebote erscheinen auch dort. Filter und Intervall stellst du in snipetools ein.';

    ui.message.replaceChildren();
    if (bot.lastError) {
      ui.message.hidden = false;
      ui.message.className = 'card message is-error';
      ui.message.append(
        h('p', { class: 'msg-title', text: 'Suche fehlgeschlagen' }),
        h('p', { text: bot.lastError }),
        bot.diag ? h('button', { type: 'button', class: 'pill pill-plain', on: { click: copyDiag } }, 'Diagnose kopieren') : null,
      );
    } else if (!bot.running && !count) {
      ui.message.hidden = false;
      ui.message.className = 'card message';
      ui.message.append(
        h('p', { class: 'msg-title', text: 'Bereit' }),
        h('p', { text: 'Tippe auf Start. Der Snipebot sucht direkt aus diesem Tab – lass ihn geöffnet. Angebote öffnen sich in einem neuen Tab.' }),
      );
    } else if (bot.running && !count && bot.lastRun) {
      ui.message.hidden = false;
      ui.message.className = 'card message';
      ui.message.append(h('p', { text: 'Keine Angebote zu diesem Filter gefunden.' }));
    } else {
      ui.message.hidden = true;
    }
  }

  function card(o) {
    const meta = [o.brand, o.size, o.condition].filter(Boolean).join(' · ');
    const photos = o.photos.length ? o.photos : [null];
    return h('a', { class: 'offer' + (o.isNew ? ' is-new' : ''), href: o.url, target: '_blank', rel: 'noopener noreferrer' },
      h('div', { class: 'media' },
        h('div', { class: 'photos' }, ...photos.map((src, i) => (src
          ? h('img', { src, alt: i === 0 ? o.title : '', loading: 'lazy', decoding: 'async' })
          : h('div', { class: 'nophoto' }, svg(['M4 7h16v12H4z', 'M4 15l4-4 4 4 3-3 5 5'], 26))))),
        o.isNew ? h('span', { class: 'badge', text: 'Neu' }) : null,
        photos.length > 1 ? h('span', { class: 'count', text: String(photos.length) }) : null,
      ),
      h('div', { class: 'body' },
        h('div', { class: 'price-row' },
          h('span', { class: 'price', text: o.price ? o.price.text : '–' }),
          o.total && o.price && o.total.text !== o.price.text ? h('span', { class: 'total', text: `inkl. ${o.total.text}` }) : null,
        ),
        h('div', { class: 'title', text: o.title || 'Ohne Titel' }),
        meta ? h('div', { class: 'meta', text: meta }) : null,
        o.category ? h('div', { class: 'cat', text: o.category }) : null,
        o.description ? h('p', { class: 'desc', text: o.description }) : null,
      ),
    );
  }

  function renderGrid() {
    ui.grid.replaceChildren(...bot.offers.map(card));
  }

  function destroy() {
    stop();
    post({ type: 'bye' });
    host.remove();
    delete window.__snipetoolsBot;
  }

  window.__snipetoolsBot = { expand: () => setExpanded(true), version: BOT_VERSION };

  /* ---------------------------------------------------------------------
     Start
     --------------------------------------------------------------------- */

  saveConfig();
  render();
  hello();
  // Kommt keine Antwort von snipetools, läuft der Bot eigenständig im Tab.
  // Wurde der Tab über snipetools gestartet (Konfiguration in der Adresse), direkt loslegen.
  if (initial && initial.autostart) start();
})();
